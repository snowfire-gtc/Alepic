import { ALPH } from 'alephium-web3';

/**
 * Форматировать баланс ALPH (с точностью до 4 знаков)
 */
export const formatAlph = (attoAlph: bigint): string => {
  const alph = Number(attoAlph) / 1e18;
  return alph.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 }) + ' ALPH';
};

/**
 * Сократить адрес кошелька (0x1234...5678)
 */
export const shortenAddress = (address: string): string => {
  if (!address) return '';
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
};

/**
 * Конвертировать индекс цвета (0-15) в HEX строку
 */
export const colorIndexToHex = (index: number): string => {
  const PALETTE = [
    '#000000', '#FFFFFF', '#FF0000', '#00FF00', '#0000FF', 
    '#FFFF00', '#00FFFF', '#FF00FF', '#C0C0C0', '#808080', 
    '#800000', '#808000', '#008000', '#800080', '#008080', '#000080'
  ];
  return PALETTE[Math.max(0, Math.min(15, index))];
};
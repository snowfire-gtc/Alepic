import { AlepicContract } from '../AlepicContract';
import { FeeCalculator } from '../../economy/feeCalculator';
import { BASE_PRICE_ALPH, TOTAL_CHUNKS, ALEPE_REWARD_TREASURY_PERCENT } from '../../economy/constants';

// Мокируем взаимодействие с нодой, тестируя только бизнес-логику клиента
jest.mock('../../config/network');
jest.mock('alephium-web3');

describe('Alepic Smart Contract Logic Emulation', () => {
  
  describe('Initial Claim Flow (Sec 6.1)', () => {
    it('should enforce increasing price for sequential claims', async () => {
      // Эмуляция состояния: уже занято 50 чанков
      const claimedCount = 50;
      const expectedPrice = BASE_PRICE_ALPH + BigInt(claimedCount); // 1 + 50 = 51 ALPH

      const result = FeeCalculator.calculateInitialClaimPrice(claimedCount);
      
      expect(result.price).toBe(expectedPrice);
      expect(result.goesToTreasury).toBe(expectedPrice); // 100% в казну
    });

    it('should prevent claiming if total chunks reached', () => {
      expect(() => FeeCalculator.calculateInitialClaimPrice(TOTAL_CHUNKS)).toThrow();
      expect(() => FeeCalculator.calculateInitialClaimPrice(TOTAL_CHUNKS + 1)).toThrow();
    });
  });

  describe('Secondary Market & Referral System (Sec 6.2 & 6.4)', () => {
    const salePrice = BigInt(1000 * 1e18); // 1000 ALPH

    it('should correctly split fees when referrer is present', () => {
      const distribution = FeeCalculator.calculateSecondaryDistribution(salePrice, true);
      
      // Общая комиссия 5% = 50 ALPH
      const totalFee = (salePrice * 5n) / 100n;
      
      // Реферер получает 20% от комиссии (1% от сделки) = 10 ALPH
      const expectedReferrerReward = (totalFee * 20n) / 100n;
      
      // Казна получает 80% от комиссии (4% от сделки) = 40 ALPH
      const expectedTreasuryShare = totalFee - expectedReferrerReward;

      expect(distribution.referrerReward).toBe(expectedReferrerReward);
      expect(distribution.treasuryShare).toBe(expectedTreasuryShare);
      expect(distribution.sellerReceives).toBe(salePrice);
      expect(distribution.buyerPays).toBe(salePrice + totalFee);
    });

    it('should route entire fee to Treasury if no referrer', () => {
      const distribution = FeeCalculator.calculateSecondaryDistribution(salePrice, false);
      
      expect(distribution.referrerReward).toBe(0n);
      expect(distribution.treasuryShare).toBe((salePrice * 5n) / 100n);
    });
  });

  describe('Alepe Game Mechanics (Sec 4 & 6.3)', () => {
    it('should calculate reward as exactly 1% of Treasury balance', () => {
      const treasuryBalance = BigInt(50000 * 1e18); // 50,000 ALPH
      const expectedReward = (treasuryBalance * BigInt(ALEPE_REWARD_TREASURY_PERCENT)) / 100n;
      
      const reward = FeeCalculator.calculateAlepeReward(treasuryBalance);
      
      expect(reward).toBe(expectedReward); // 500 ALPH
    });

    it('should handle zero treasury balance gracefully', () => {
      const reward = FeeCalculator.calculateAlepeReward(0n);
      expect(reward).toBe(0n);
    });
  });
});
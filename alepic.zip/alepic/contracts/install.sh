# 1. Установите Node.js (версия 18+)
node -v  # должно быть >= 18.0.0

# 2. Создайте проект через Alephium CLI
npx @alephium/cli init alepic -t base

# 3. Перейдите в директорию проекта
cd alepic

# 4. Установите зависимости
npm install
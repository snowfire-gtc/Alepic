/**
 * Конфигурация режима Биллборд (Раздел 8.1 Whitepaper)
 */

export interface BillboardProfile {
  id: string;
  name: string;
  location?: string;
  zoomLevel: number;
  offsetX: number;
  offsetY: number;
  fitToScreen: boolean;
  refreshInterval: number;
  requirePinToExit: boolean;
}

export const DEFAULT_BILLBOARD_PROFILES: BillboardProfile[] = [
  {
    id: 'full-view',
    name: 'Full Canvas View (4K)',
    zoomLevel: 0.2,
    offsetX: 0,
    offsetY: 0,
    fitToScreen: true,
    refreshInterval: 5000,
    requirePinToExit: true,
  },
  {
    id: 'center-focus',
    name: 'Center Focus (Alepe Start)',
    zoomLevel: 1.5,
    offsetX: -500,
    offsetY: -300,
    fitToScreen: false,
    refreshInterval: 3000,
    requirePinToExit: true,
  }
];

// БЕЗОПАСНОСТЬ: Читаем из .env, fallback на дефолт только для dev
export const DEFAULT_ADMIN_PIN = process.env.EXPO_PUBLIC_BILLBOARD_PIN || '7070'; 

export const BILLBOARD_SCHEME = 'alepic';
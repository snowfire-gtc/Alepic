import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { CustomModal } from '../components/ui/Modal';
import { Button } from '../components/ui/Button';
import { useWallet } from '../hooks/useWallet';
import { contractService } from '../contracts/AlepicContract';
import { FeeCalculator } from '../economy/feeCalculator';
import { formatAlph, shortenAddress, colorIndexToHex } from '../utils/formatters';
import { logger } from '../utils/logger';
import { ChunkInfo } from '../contracts/types';

// Интерфейс элемента списка (расширенный ChunkInfo)
interface MarketplaceItem extends ChunkInfo {
  id: number;
  salePrice?: bigint; // Цена, если выставлен на продажу
  sellerAddress?: string;
}

export default function MarketplaceScreen() {
  const router = useRouter();
  const { isConnected, address, balance, connect } = useWallet();
  
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [items, setItems] = useState<MarketplaceItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<MarketplaceItem | null>(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [txLoading, setTxLoading] = useState(false);

  // Загрузка данных рынка
  const fetchMarketData = async () => {
    try {
      setLoading(true);
      // В реальном приложении здесь будет запрос к индексатору или сканирование событий контракта
      // Эмуляция: получаем случайные чанки, которые "выставлены на продажу"
      const mockData: MarketplaceItem[] = [];
      
      // Симуляция получения данных из блокчейна (события TransferChunk)
      // Для демо генерируем несколько фейковых лотов
      for (let i = 0; i < 20; i++) {
        const randomId = Math.floor(Math.random() * 34560);
        const chunkInfo = await contractService.getChunkInfo(randomId).catch(() => null);
        
        if (chunkInfo && chunkInfo.ownerId) {
          // Добавляем фиктивную цену продажи (в реальности берется из события или оффчейн ордера)
          const basePrice = BigInt(10 + Math.floor(Math.random() * 100)); 
          mockData.push({
            ...chunkInfo,
            id: randomId,
            salePrice: basePrice * BigInt(1e18), // Конвертируем в attoAlph
            sellerAddress: chunkInfo.ownerId,
          });
        }
      }
      
      setItems(mockData);
    } catch (error) {
      logger.error('Marketplace', 'Failed to fetch market data', error);
      Alert.alert('Error', 'Failed to load marketplace data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchMarketData();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchMarketData();
  };

  const handleBuyPress = (item: MarketplaceItem) => {
    if (!isConnected) {
      connect();
      return;
    }
    setSelectedItem(item);
    setModalVisible(true);
  };

  const confirmPurchase = async () => {
    if (!selectedItem || !selectedItem.salePrice) return;

    setTxLoading(true);
    try {
      // Расчет комиссии и итоговой суммы
      const distribution = FeeCalculator.calculateSecondaryDistribution(
        selectedItem.salePrice,
        false // В этом экране реферер не указан явно, но можно добавить поле ввода
      );

      logger.info('Marketplace', `Buying chunk ${selectedItem.id}`, {
        price: distribution.buyerPays.toString(),
        fee: distribution.totalFee.toString(),
      });

      // Вызов контракта transferChunk
      // Примечание: В реальном коде нужно передать адрес продавца и цену
      await contractService.transferChunk(
        selectedItem.id,
        selectedItem.sellerAddress!,
        selectedItem.salePrice,
        undefined // referrer
      );

      Alert.alert('Success', `Chunk #${selectedItem.id} purchased successfully!`);
      setModalVisible(false);
      fetchMarketData(); // Обновить список
    } catch (error: any) {
      logger.error('Marketplace', 'Purchase failed', error);
      Alert.alert('Transaction Failed', error.message || 'Unknown error occurred');
    } finally {
      setTxLoading(false);
    }
  };

  const renderItem = ({ item }: { item: MarketplaceItem }) => (
    <TouchableOpacity 
      style={styles.card} 
      onPress={() => handleBuyPress(item)}
      activeOpacity={0.7}
    >
      {/* Превью чанка (цвет) */}
      <View 
        style={[
          styles.chunkPreview, 
          { backgroundColor: colorIndexToHex(item.colorIndex) }
        ]} 
      />
      
      <View style={styles.cardContent}>
        <Text style={styles.chunkId}>Chunk #{item.id}</Text>
        <Text style={styles.ownerLabel}>Owner: {shortenAddress(item.sellerAddress || '')}</Text>
        
        <View style={styles.priceRow}>
          <Text style={styles.priceLabel}>Price:</Text>
          <Text style={styles.priceValue}>
            {item.salePrice ? formatAlph(item.salePrice) : 'N/A'}
          </Text>
        </View>

        <Button 
          title="Buy Now" 
          onPress={() => handleBuyPress(item)} 
          variant="primary"
          style={styles.buyButton}
        />
      </View>
    </TouchableOpacity>
  );

  if (loading && !refreshing) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#00FF00" />
        <Text style={styles.loadingText}>Loading Marketplace...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={items}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#00FF00" />
        }
        ListEmptyComponent={
          <Text style={styles.emptyText}>No chunks currently for sale.</Text>
        }
      />

      {/* Модальное окно подтверждения покупки */}
      <CustomModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        title="Confirm Purchase"
        loading={txLoading}
        onConfirm={confirmPurchase}
        confirmText="Confirm Buy"
      >
        {selectedItem && (
          <View style={styles.modalContent}>
            <Text style={styles.modalText}>You are buying <Text style={styles.bold}>Chunk #{selectedItem.id}</Text></Text>
            <Text style={styles.modalText}>Current Color Index: {selectedItem.colorIndex}</Text>
            
            <View style={styles.divider} />
            
            <Text style={styles.modalLabel}>Sale Price:</Text>
            <Text style={styles.modalValue}>{selectedItem.salePrice ? formatAlph(selectedItem.salePrice) : '0 ALPH'}</Text>
            
            <Text style={styles.modalLabel}>Platform Fee (5%):</Text>
            <Text style={styles.modalValue}>
              {selectedItem.salePrice ? formatAlph(FeeCalculator.calculateSecondaryDistribution(selectedItem.salePrice, false).totalFee) : '0 ALPH'}
            </Text>
            
            <View style={styles.divider} />
            
            <Text style={styles.modalLabel}>Total to Pay:</Text>
            <Text style={[styles.modalValue, styles.totalValue]}>
              {selectedItem.salePrice ? formatAlph(FeeCalculator.calculateSecondaryDistribution(selectedItem.salePrice, false).buyerPays) : '0 ALPH'}
            </Text>

            {!isConnected && (
              <Text style={styles.warningText}>Please connect your wallet first.</Text>
            )}
          </View>
        )}
      </CustomModal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  centerContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#FFF', marginTop: 10 },
  listContent: { padding: 10 },
  card: {
    flex: 1,
    margin: 5,
    backgroundColor: '#1A1A1A',
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#333',
  },
  chunkPreview: {
    width: '100%',
    height: 80,
  },
  cardContent: { padding: 10 },
  chunkId: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  ownerLabel: { color: '#888', fontSize: 12, marginVertical: 4 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  priceLabel: { color: '#AAA' },
  priceValue: { color: '#00FF00', fontWeight: 'bold' },
  buyButton: { marginTop: 5 },
  emptyText: { color: '#666', textAlign: 'center', marginTop: 50 },
  
  // Modal Styles
  modalContent: { paddingVertical: 10 },
  modalText: { color: '#DDD', fontSize: 14, marginBottom: 5 },
  bold: { color: '#FFF', fontWeight: 'bold' },
  divider: { height: 1, backgroundColor: '#333', marginVertical: 10 },
  modalLabel: { color: '#888', fontSize: 12 },
  modalValue: { color: '#FFF', fontSize: 16, marginBottom: 8 },
  totalValue: { color: '#00FF00', fontSize: 18, fontWeight: 'bold' },
  warningText: { color: '#FF4444', marginTop: 10, textAlign: 'center' },
});
import React from 'react';
import { Canvas, Image, Rect, Circle } from '@shopify/react-native-skia';
import { useImage } from '@shopify/react-native-skia';
import { StyleSheet } from 'react-native';

interface AlepeOverlayProps {
  x: number;
  y: number;
  zoom: number;
  offset: { x: number; y: number };
  screenWidth: number;
  screenHeight: number;
}

const ALEPE_SIZE = 64; // Размер талисмана в пикселях холста

export const AlepeOverlay: React.FC<AlepeOverlayProps> = ({
  x, y, zoom, offset, screenWidth, screenHeight
}) => {
  // Загрузка спрайта Alepe (путь к ассету)
  const alepeImage = useImage(require('../../assets/images/alepe_mascot.png'));

  if (!alepeImage) return null;

  // Расчет позиции с учетом трансформаций холста
  const renderX = x * zoom + offset.x;
  const renderY = y * zoom + offset.y;
  const renderSize = ALEPE_SIZE * zoom;

  // Проверка видимости (Optimization: не рисовать, если за пределами экрана)
  if (
    renderX + renderSize < 0 ||
    renderX > screenWidth ||
    renderY + renderSize < 0 ||
    renderY > screenHeight
  ) {
    return null;
  }

  return (
    <Canvas style={StyleSheet.absoluteFill}>
      {/* Рисуем Alepe */}
      <Image
        image={alepeImage}
        x={renderX}
        y={renderY}
        width={renderSize}
        height={renderSize}
        fit="cover"
      />
      
      {/* Эффект свечения вокруг Alepe */}
      <Rect
        x={renderX - 5}
        y={renderY - 5}
        width={renderSize + 10}
        height={renderSize + 10}
        color="transparent"
        strokeCap="round"
        strokeJoin="round"
        style="stroke"
        strokeWidth={2}
        colorValue="#00FF00" // Зеленое свечение
      />
    </Canvas>
  );
};
import { renderHook, act, waitFor } from '@testing-library/react-native';
import { useWallet } from '../useWallet';
import { alephium } from 'alephium-web3';
import { networkManager } from '../../config/network';

// Глубокий мок библиотеки alephium-web3
jest.mock('alephium-web3', () => ({
  alephium: {
    wallet: {
      connect: jest.fn(),
      disconnect: jest.fn(),
      getSelectedAccount: jest.fn(),
    },
    client: {
      accounts: {
        getBalances: jest.fn(),
      },
    },
  },
  ALPH: { id: 'ALPH_ID' },
}));

describe('useWallet Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (alephium.wallet.connect as jest.Mock).mockResolvedValue({
      getSelectedAccount: () => ({ address: '0xTestAddress' }),
    });
    (alephium.client.accounts.getBalances as jest.Mock).mockResolvedValue({
      balances: [{ asset: 'ALPH_ID', amount: BigInt(5 * 1e18) }], // 5 ALPH
    });
  });

  it('should connect wallet and fetch balance successfully', async () => {
    const { result } = renderHook(() => useWallet());

    expect(result.current.isConnected).toBe(false);
    expect(result.current.address).toBeNull();

    await act(async () => {
      await result.current.connect();
    });

    expect(alephium.wallet.connect).toHaveBeenCalled();
    expect(alephium.client.accounts.getBalances).toHaveBeenCalledWith('0xTestAddress');
    
    await waitFor(() => {
      expect(result.current.isConnected).toBe(true);
      expect(result.current.address).toBe('0xTestAddress');
      expect(result.current.balance).toBe(BigInt(5 * 1e18));
    });
  });

  it('should handle connection failure gracefully', async () => {
    (alephium.wallet.connect as jest.Mock).mockRejectedValue(new Error('User rejected'));

    const { result } = renderHook(() => useWallet());

    await act(async () => {
      await result.current.connect();
    });

    expect(result.current.isConnected).toBe(false);
    expect(result.current.error).toBe('User rejected');
    expect(result.current.loading).toBe(false);
  });

  it('should update balance when network changes', async () => {
    const { result } = renderHook(() => useWallet());
    
    // Подключаемся
    await act(async () => { await result.current.connect(); });
    
    // Сбрасываем моки для имитации нового баланса в другой сети
    (alephium.client.accounts.getBalances as jest.Mock).mockResolvedValueOnce({
      balances: [{ asset: 'ALPH_ID', amount: BigInt(10 * 1e18) }], // 10 ALPH
    });

    // Эмулируем смену сети (в реальном приложении это триггерится контекстом)
    // Здесь просто вызываем refresh вручную для теста
    await act(async () => {
      await result.current.refreshBalance();
    });

    expect(result.current.balance).toBe(BigInt(10 * 1e18));
  });
});
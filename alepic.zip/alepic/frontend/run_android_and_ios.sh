# Предварительная настройка
npm install -g eas-cli
eas build:configure

# Сборка для Android
eas build --platform android --profile development

# Сборка для iOS (требуется macOS)
eas build --platform ios --profile development
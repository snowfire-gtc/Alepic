import { ChunkInfo } from '../contracts/types';
import { FeeCalculator } from '../economy/feeCalculator';
import { AlepeJumpEvent, Position } from './types';

const CHUNK_SIZE = 16;
const GRID_WIDTH = 256; // 4096 / 16

export class RewardChecker {
  /**
   * Определить ID чанка по координатам позиции Alepe
   */
  static getChunkIdFromPosition(pos: Position): number {
    const chunkX = Math.floor(pos.x / CHUNK_SIZE);
    const chunkY = Math.floor(pos.y / CHUNK_SIZE);
    return chunkY * GRID_WIDTH + chunkX;
  }

  /**
   * Проверить условия выдачи награды после прыжка Alepe.
   * @param chunkInfo Информация о чанке, куда приземлилась Alepe
   * @param treasuryBalance Текущий баланс казны
   * @returns Объект события прыжка с данными о награде
   */
  static processJumpResult(
    chunkInfo: ChunkInfo,
    treasuryBalance: bigint,
    newPos: Position,
    prevPos: Position,
    blockHeight: bigint
  ): AlepeJumpEvent {
    const chunkId = this.getChunkIdFromPosition(newPos);
    let rewardIssued = false;
    let rewardAmount = 0n;
    let winnerAddress: string | undefined = undefined;

    // Логика Раздела 6.3: Если чанк не занят -> награды нет
    if (chunkInfo.ownerId) {
      // Чанк занят -> выдаем 1% от казны владельцу
      rewardAmount = FeeCalculator.calculateAlepeReward(treasuryBalance);
      
      // Защита от нуля, если казна пуста
      if (rewardAmount > 0n) {
        rewardIssued = true;
        winnerAddress = chunkInfo.ownerId;
      }
    }

    return {
      previousPosition: prevPos,
      newPosition: newPos,
      blockHeight,
      timestamp: Date.now(),
      landedChunkId: chunkId,
      rewardIssued,
      rewardAmount: rewardIssued ? rewardAmount : undefined,
      winnerAddress: rewardIssued ? winnerAddress : undefined,
    };
  }
}
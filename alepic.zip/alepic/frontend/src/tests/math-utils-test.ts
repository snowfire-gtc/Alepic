import { pixelToChunkId, chunkIdToPixel, wrapCoordinate } from '../utils/math';

describe('Math & Grid Utilities (Whitepaper Sec 3.2 & 4)', () => {
  
  const CANVAS_WIDTH = 4096;
  const CANVAS_HEIGHT = 2160;
  const CHUNK_SIZE = 16;
  const GRID_WIDTH = 256; // 4096 / 16
  const GRID_HEIGHT = 135; // 2160 / 16
  const TOTAL_CHUNKS = 34560;

  describe('pixelToChunkId', () => {
    it('should convert center pixel to correct chunk ID', () => {
      // Центр холста (2048, 1080)
      // Chunk X = floor(2048/16) = 128
      // Chunk Y = floor(1080/16) = 67
      // ID = 67 * 256 + 128 = 17152 + 128 = 17280
      expect(pixelToChunkId(2048, 1080)).toBe(17280);
    });

    it('should handle edge pixels correctly', () => {
      // Последний пиксель первого чанка (15, 15) -> ID 0
      expect(pixelToChunkId(15, 15)).toBe(0);
      
      // Первый пиксель второго чанка по X (16, 0) -> ID 1
      expect(pixelToChunkId(16, 0)).toBe(1);
      
      // Первый пиксель второго ряда (0, 16) -> ID 256
      expect(pixelToChunkId(0, 16)).toBe(256);
    });

    it('should return -1 for out of bounds coordinates', () => {
      expect(pixelToChunkId(-1, 0)).toBe(-1);
      expect(pixelToChunkId(4096, 0)).toBe(-1); // Ровно граница
      expect(pixelToChunkId(0, 2160)).toBe(-1);
      expect(pixelToChunkId(5000, 5000)).toBe(-1);
    });
  });

  describe('chunkIdToPixel', () => {
    it('should convert chunk ID back to top-left pixel coordinates', () => {
      const pos = chunkIdToPixel(17280);
      expect(pos.x).toBe(2048);
      expect(pos.y).toBe(1072); // 67 * 16 = 1072 (верхний край чанка)
    });

    it('should handle first and last chunks', () => {
      const first = chunkIdToPixel(0);
      expect(first.x).toBe(0);
      expect(first.y).toBe(0);

      const last = chunkIdToPixel(TOTAL_CHUNKS - 1); // 34559
      // X = 255 * 16 = 4080
      // Y = 134 * 16 = 2144
      expect(last.x).toBe(4080);
      expect(last.y).toBe(2144);
    });
  });

  describe('wrapCoordinate (Alepe Logic)', () => {
    it('should return same value if within bounds', () => {
      expect(wrapCoordinate(100, 4096)).toBe(100);
    });

    it('should wrap around positive overflow', () => {
      // 4096 + 10 -> 10
      expect(wrapCoordinate(4106, 4096)).toBe(10);
      // 4096 * 2 + 5 -> 5
      expect(wrapCoordinate(8197, 4096)).toBe(5);
    });

    it('should wrap around negative overflow', () => {
      // -10 -> 4086
      expect(wrapCoordinate(-10, 4096)).toBe(4086);
      // -4096 -> 0
      expect(wrapCoordinate(-4096, 4096)).toBe(0);
    });
  });
});
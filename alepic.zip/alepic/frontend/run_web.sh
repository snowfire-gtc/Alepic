
# Сборка веб-версии
npx expo export:web

# Запуск локального сервера
npx expo start --web
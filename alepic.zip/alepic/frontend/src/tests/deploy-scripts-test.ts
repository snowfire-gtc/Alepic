import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

// Mock execSync для безопасного тестирования без реального деплоя
jest.mock('child_process', () => ({
  execSync: jest.fn(),
}));

describe('Deployment & Build Scripts', () => {
  const rootDir = path.resolve(__dirname, '../..');
  const artifactsDir = path.join(rootDir, 'src/contracts/artifacts');
  const contractAddressFile = path.join(artifactsDir, 'contractAddress.ts');

  beforeEach(() => {
    jest.clearAllMocks();
    // Создаем временную директорию если нет
    if (!fs.existsSync(artifactsDir)) {
      fs.mkdirSync(artifactsDir, { recursive: true });
    }
  });

  afterEach(() => {
    // Очистка тестовых файлов
    if (fs.existsSync(contractAddressFile)) {
      fs.unlinkSync(contractAddressFile);
    }
  });

  it('generate-abi.sh should create types file', () => {
    // Эмуляция успешного выполнения скрипта
    (execSync as jest.Mock).mockReturnValue(Buffer.from('Compilation successful'));

    // В реальном тесте здесь был бы вызов:
    // execSync('./scripts/generate-abi.sh', { cwd: rootDir });
    
    // Проверка логики создания файла (эмуляция)
    const mockContent = `export interface ChunkInfo { ... }`;
    fs.writeFileSync(contractAddressFile, mockContent); // Эмуляция создания

    expect(fs.existsSync(contractAddressFile)).toBe(true);
    expect(execSync).toHaveBeenCalledTimes(1); // Компиляция
  });

  it('deploy-contract.sh should update .env.local with new address', () => {
    const mockOutput = `
      Deploying...
      Success!
      "contractId":"0xNewDeployedAddress123"
    `;
    (execSync as jest.Mock).mockReturnValue(Buffer.from(mockOutput));

    // Запуск логики парсинга (упрощенно)
    const match = mockOutput.match(/"contractId":"([^"]*)"/);
    const newAddress = match ? match[1] : null;

    expect(newAddress).toBe('0xNewDeployedAddress123');
    
    // Проверка, что скрипт попытался бы записать в .env
    // (В полном тесте проверяем содержимое файла после выполнения)
  });
});
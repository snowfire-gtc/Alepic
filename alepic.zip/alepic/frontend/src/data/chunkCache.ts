import AsyncStorage from '@react-native-async-storage/async-storage';
import { ChunkInfo } from '../contracts/types';
import { logger } from '../utils/logger';
import { storageService } from '../services/storageService';

const CACHE_META_KEY = 'alepic_cache_metadata_v1';
const DEBOUNCE_DELAY_MS = 1000; // Задержка перед записью на диск (мс)

interface CacheMetadata {
  lastSyncedBlockHeight: bigint;
  totalCachedChunks: number;
  lastUpdatedTimestamp: number;
}

/**
 * Менеджер кэша чанков для Alepic Client.
 * Реализует логику реконструкции изображения из локального хранилища
 * и синхронизации с блокчейном (Раздел 3.3 WP).
 */
class ChunkCacheManager {
  private memoryStore: Map<number, ChunkInfo>;
  private pendingUpdates: Map<number, ChunkInfo>;
  private metadata: CacheMetadata;
  private saveTimeout: NodeJS.Timeout | null;
  private isInitialized: boolean;

  constructor() {
    this.memoryStore = new Map();
    this.pendingUpdates = new Map();
    this.saveTimeout = null;
    this.isInitialized = false;
    
    this.metadata = {
      lastSyncedBlockHeight: 0n,
      totalCachedChunks: 0,
      lastUpdatedTimestamp: Date.now(),
    };
  }

  /**
   * Инициализация кэша при старте приложения.
   * Загружает метаданные и существующие чанки из постоянного хранилища.
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      logger.info('ChunkCache', 'Initializing cache subsystem...');

      // 1. Загрузка метаданных
      const metaJson = await AsyncStorage.getItem(CACHE_META_KEY);
      if (metaJson) {
        const parsed = JSON.parse(metaJson);
        this.metadata = {
          ...parsed,
          lastSyncedBlockHeight: BigInt(parsed.lastSyncedBlockHeight),
        };
      }

      // 2. Загрузка данных чанков через сервис хранения
      // В реальной реализации storageService.getChunks() может возвращать большой объект,
      // поэтому важно следить за потреблением памяти.
      const storedChunks = await storageService.getChunks();
      const entries = Object.entries(storedChunks);
      
      entries.forEach(([key, value]) => {
        this.memoryStore.set(parseInt(key), value as ChunkInfo);
      });

      this.isInitialized = true;
      logger.info('ChunkCache', `Initialized with ${this.memoryStore.size} chunks. Last sync: ${this.metadata.lastSyncedBlockHeight}`);
    } catch (error) {
      logger.error('ChunkCache', 'Initialization failed, starting with empty cache', error);
      this.isInitialized = true; // Продолжаем работу с пустым кэшем
    }
  }

  /**
   * Получить данные чанка по ID.
   * @returns ChunkInfo или undefined, если чанк еще не загружен.
   */
  get(chunkId: number): ChunkInfo | undefined {
    return this.memoryStore.get(chunkId);
  }

  /**
   * Получить данные нескольких чанков (для оптимизации рендеринга области видимости).
   */
  getMany(chunkIds: number[]): Map<number, ChunkInfo> {
    const result = new Map<number, ChunkInfo>();
    chunkIds.forEach(id => {
      const data = this.memoryStore.get(id);
      if (data) result.set(id, data);
    });
    return result;
  }

  /**
   * Обновить состояние чанка в кэше.
   * Использует отложенную запись (debounce) для оптимизации производительности диска.
   */
  set(chunkId: number, info: ChunkInfo): void {
    if (!this.isInitialized) {
      logger.warn('ChunkCache', 'Attempted to set chunk before initialization');
      return;
    }

    // Обновление в RAM (мгновенно)
    this.memoryStore.set(chunkId, info);
    this.pendingUpdates.set(chunkId, info);

    // Планирование записи на диск
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
    }

    this.saveTimeout = setTimeout(() => {
      this.flushToDisk().catch(err => logger.error('ChunkCache', 'Auto-save failed', err));
    }, DEBOUNCE_DELAY_MS);
  }

  /**
   * Массовое обновление кэша (например, после синхронизации пакета блоков).
   */
  setMany(chunks: Record<number, ChunkInfo>): void {
    Object.entries(chunks).forEach(([id, info]) => {
      this.memoryStore.set(parseInt(id), info);
      this.pendingUpdates.set(parseInt(id), info);
    });

    if (this.saveTimeout) clearTimeout(this.saveTimeout);
    this.saveTimeout = setTimeout(() => {
      this.flushToDisk().catch(err => logger.error('ChunkCache', 'Batch save failed', err));
    }, 500);
  }

  /**
   * Сброс накопленных изменений на диск (AsyncStorage).
   */
  private async flushToDisk(): Promise<void> {
    if (this.pendingUpdates.size === 0) return;

    try {
      const updates = Object.fromEntries(this.pendingUpdates);
      
      // Сохранение через сервис (который управляет квотами и LRU)
      await storageService.saveChunks(updates);

      // Обновление метаданных
      this.metadata.totalCachedChunks = this.memoryStore.size;
      this.metadata.lastUpdatedTimestamp = Date.now();
      
      await AsyncStorage.setItem(CACHE_META_KEY, JSON.stringify({
        ...this.metadata,
        lastSyncedBlockHeight: this.metadata.lastSyncedBlockHeight.toString(),
      }));

      this.pendingUpdates.clear();
      logger.debug('ChunkCache', `Flushed ${Object.keys(updates).length} chunks to persistent storage`);
    } catch (error) {
      logger.error('ChunkCache', 'Critical error flushing to disk', error);
      // Не очищаем pendingUpdates при ошибке, чтобы повторить попытку позже
    }
  }

  /**
   * Обновить высоту последнего обработанного блока.
   * Критично для инкрементальной синхронизации (Раздел 3.3).
   */
  updateSyncHeight(blockHeight: bigint): void {
    this.metadata.lastSyncedBlockHeight = blockHeight;
    // Метаданные высоты блока сохраняем немедленно, так как это точка восстановления
    AsyncStorage.setItem(CACHE_META_KEY, JSON.stringify({
      ...this.metadata,
      lastSyncedBlockHeight: blockHeight.toString(),
    })).catch(e => logger.error('ChunkCache', 'Failed to save sync height', e));
  }

  getSyncHeight(): bigint {
    return this.metadata.lastSyncedBlockHeight;
  }

  /**
   * Полная очистка кэша (для отладки или принудительной ресинхронизации).
   */
  async clear(): Promise<void> {
    if (this.saveTimeout) clearTimeout(this.saveTimeout);
    
    this.memoryStore.clear();
    this.pendingUpdates.clear();
    this.metadata = {
      lastSyncedBlockHeight: 0n,
      totalCachedChunks: 0,
      lastUpdatedTimestamp: Date.now(),
    };

    await storageService.clearCache();
    await AsyncStorage.removeItem(CACHE_META_KEY);
    
    logger.warn('ChunkCache', 'Cache cleared successfully');
  }

  getStats() {
    return {
      inMemoryCount: this.memoryStore.size,
      pendingWritesCount: this.pendingUpdates.size,
      lastSyncedBlock: this.metadata.lastSyncedBlockHeight.toString(),
      isInitialized: this.isInitialized,
    };
  }
}

// Экспорт Singleton экземпляра
export const chunkCache = new ChunkCacheManager();
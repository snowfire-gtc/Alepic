import { useState, useEffect } from 'react';
import { alephium, AccountAssetBalance } from 'alephium-web3';
import { networkManager } from '../config/network';

export const useWallet = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [address, setAddress] = useState<string | null>(null);
  const [balance, setBalance] = useState<bigint>(0n);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const connect = async () => {
    setLoading(true);
    setError(null);
    try {
      // Запрос подключения через встроенный кошелек браузера или мобильное приложение
      const wallet = await alephium.wallet.connect({ 
        permissions: ['view-assets', 'sign-transactions'] 
      });
      
      const account = wallet.getSelectedAccount();
      if (!account) throw new Error('No account selected');

      setAddress(account.address);
      setIsConnected(true);
      
      // Обновление баланса
      await updateBalance(account.address);
    } catch (err: any) {
      setError(err.message || 'Failed to connect wallet');
    } finally {
      setLoading(false);
    }
  };

  const disconnect = () => {
    alephium.wallet.disconnect();
    setIsConnected(false);
    setAddress(null);
    setBalance(0n);
  };

  const updateBalance = async (addr: string) => {
    try {
      const provider = networkManager.getProvider();
      const balances = await provider.accounts.getBalances(addr);
      const alphBalance = balances.balances.find(b => b.asset === ALPH.id) || { amount: 0n };
      setBalance(alphBalance.amount);
    } catch (e) {
      console.warn('Could not fetch balance', e);
    }
  };

  // Авто-переподключение при смене сети
  useEffect(() => {
    if (isConnected && address) {
      updateBalance(address);
    }
  }, [networkManager.getConfig().id]);

  return { isConnected, address, balance, loading, error, connect, disconnect, refreshBalance: () => address && updateBalance(address) };
};
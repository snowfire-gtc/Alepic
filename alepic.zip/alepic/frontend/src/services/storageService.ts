import AsyncStorage from '@react-native-async-storage/async-storage';
import { ChunkInfo } from '../contracts/types';

const CHUNK_CACHE_KEY = 'alepic_chunk_cache_v1';
const USER_SETTINGS_KEY = 'alepic_settings_v1';
const MAX_CACHED_CHUNKS = 5000;

export interface AppSettings {
  network: 'mainnet' | 'testnet' | 'devnet';
  showAlepeOverlay: boolean;
  language: 'en' | 'ru';
  lastSyncBlock: bigint;
  
  // Настройки Биллборда (Раздел 8.1)
  isBillboardMode: boolean;
  activeBillboardProfileId?: string;
  adminPinHash?: string; // Хэш PIN-кода (опционально)
}

class StorageService {
  // ... (существующие методы saveChunks, getChunks опущены для краткости) ...

  async saveChunks(chunks: Record<number, ChunkInfo>): Promise<void> {
    // Реализация из предыдущих ответов
    try {
      const existingData = await this.getChunks();
      const mergedData = { ...existingData, ...chunks };
      const keys = Object.keys(mergedData);
      if (keys.length > MAX_CACHED_CHUNKS) {
        const keysToDelete = keys.slice(0, keys.length - MAX_CACHED_CHUNKS);
        keysToDelete.forEach(key => delete mergedData[parseInt(key)]);
      }
      await AsyncStorage.setItem(CHUNK_CACHE_KEY, JSON.stringify(mergedData));
    } catch (error) {
      console.error('Failed to save chunks', error);
    }
  }

  async getChunks(): Promise<Record<number, ChunkInfo>> {
    try {
      const data = await AsyncStorage.getItem(CHUNK_CACHE_KEY);
      return data ? JSON.parse(data) : {};
    } catch (error) {
      return {};
    }
  }

  async saveSettings(settings: Partial<AppSettings>): Promise<void> {
    try {
      const current = await this.getSettings();
      const updated = { ...current, ...settings };
      await AsyncStorage.setItem(USER_SETTINGS_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Failed to save settings', error);
    }
  }

  async getSettings(): Promise<AppSettings> {
    try {
      const data = await AsyncStorage.getItem(USER_SETTINGS_KEY);
      const defaults: AppSettings = {
        network: 'testnet',
        showAlepeOverlay: true,
        language: 'en',
        lastSyncBlock: 0n,
        isBillboardMode: false,
        activeBillboardProfileId: undefined,
      };
      return data ? { ...defaults, ...JSON.parse(data) } : defaults;
    } catch (error) {
      return {
        network: 'testnet',
        showAlepeOverlay: true,
        language: 'en',
        lastSyncBlock: 0n,
        isBillboardMode: false,
      };
    }
  }

  /**
   * Специфичный метод для обновления статуса биллборда
   */
  async saveBillboardSettings(settings: Partial<AppSettings>): Promise<void> {
    return this.saveSettings({
      isBillboardMode: settings.isBillboardMode,
      activeBillboardProfileId: settings.activeBillboardProfileId,
    });
  }

  /**
   * Быстрая проверка статуса биллборда
   */
  async getBillboardStatus(): Promise<{ isActive: boolean; profileId?: string }> {
    const settings = await this.getSettings();
    return {
      isActive: settings.isBillboardMode,
      profileId: settings.activeBillboardProfileId,
    };
  }

  async clearCache(): Promise<void> {
    await AsyncStorage.removeItem(CHUNK_CACHE_KEY);
  }
}

export const storageService = new StorageService();
import React, { useState, useCallback } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { AlepicCanvas } from '../components/canvas/AlepicCanvas';
import { AlepeOverlay } from '../components/canvas/AlepeOverlay';
import { ZoomControls } from '../components/controls/ZoomControls';
import { ColorPicker } from '../components/controls/ColorPicker';
import { WalletConnect } from '../components/controls/WalletConnect';
import { useAlepeState } from '../hooks/useAlepeState';
import { useVisibleChunks } from '../hooks/useVisibleChunks';
import { contractService } from '../contracts/AlepicContract';
import { logger } from '../utils/logger';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export default function IndexScreen() {
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [selectedColor, setSelectedColor] = useState(5); // Default Green (Index 5)
  
  const { state: alepeState } = useAlepeState();
  // Хук для определения видимых чанков (оптимизация рендеринга)
  const visibleChunks = useVisibleChunks(zoom, offset.x, offset.y);

  const handleChunkPress = useCallback(async (chunkId: number) => {
    logger.info('IndexScreen', `Chunk ${chunkId} pressed`);
    // Логика открытия модального окна покупки/редактирования
    // В реальном приложении здесь открывается Modal или навигация на chunk/[id]
  }, []);

  const handleUpdateColor = async (chunkId: number) => {
    try {
      await contractService.updateChunkColor(chunkId, selectedColor);
      // Уведомление об успехе будет отправлено через AppController/NotificationService
    } catch (e) {
      logger.error('IndexScreen', 'Failed to update color', e);
    }
  };

  return (
    <View style={styles.container}>
      {/* Слой Рендеринга Холста */}
      <AlepicCanvas
        zoom={zoom}
        offset={offset}
        onOffsetChange={setOffset}
        visibleChunkIds={visibleChunks}
        onChunkPress={handleChunkPress}
        onChunkLongPress={handleUpdateColor} // Долгое нажатие для смены цвета
      />

      {/* Слой Талисмана Alepe */}
      {alepeState && (
        <AlepeOverlay
          x={alepeState.x}
          y={alepeState.y}
          zoom={zoom}
          offset={offset}
          screenWidth={SCREEN_WIDTH}
          screenHeight={SCREEN_HEIGHT}
        />
      )}

      {/* UI Controls Layer */}
      <WalletConnect />
      
      <ZoomControls
        currentZoom={zoom}
        onZoomIn={() => setZoom(z => Math.min(z * 1.5, 20))}
        onZoomOut={() => setZoom(z => Math.max(z / 1.5, 0.1))}
        onReset={() => { setZoom(1); setOffset({ x: 0, y: 0 }); }}
      />

      <ColorPicker
        selectedIndex={selectedColor}
        onSelect={setSelectedColor}
      />
      
      {/* Кнопка перехода в режим Биллборда */}
      {/* ... */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
});
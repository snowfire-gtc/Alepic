import {
  BASE_PRICE_ALPH,
  PRICE_INCREMENT_ALPH,
  TOTAL_CHUNKS,
  SECONDARY_SALE_FEE_PERCENT,
  REFERRER_SHARE_OF_FEE_PERCENT,
  TREASURY_SHARE_OF_FEE_PERCENT,
} from './constants';

export interface FeeDistributionResult {
  sellerReceives: bigint;
  treasuryShare: bigint;
  referrerReward: bigint;
  totalFee: bigint;
  buyerPays: bigint; // Цена + Комиссия
}

export interface InitialClaimResult {
  price: bigint;
  goesToTreasury: bigint;
}

export class FeeCalculator {
  /**
   * Рассчитать цену для первичного захвата незанятого чанка.
   * Формула: Price = 1 + (CountOfAlreadyClaimedChunks)
   * Все средства идут в Казну (Раздел 6.2).
   */
  static calculateInitialClaimPrice(claimedCount: number): InitialClaimResult {
    if (claimedCount < 0 || claimedCount >= TOTAL_CHUNKS) {
      throw new Error(`Invalid claimed count: ${claimedCount}. Max is ${TOTAL_CHUNKS - 1}`);
    }

    const price = BASE_PRICE_ALPH + BigInt(claimedCount) * PRICE_INCREMENT_ALPH;

    return {
      price,
      goesToTreasury: price, // 100% идет в казну при первичной продаже
    };
  }

  /**
   * Рассчитать распределение средств при вторичной продаже.
   * @param salePrice Цена, которую продавец хочет получить (до вычета комиссии)
   * @param hasReferrer Наличие адреса реферера в транзакции
   * 
   * Логика:
   * Buyer pays = SalePrice + Fee
   * Fee = SalePrice * 5%
   * Referrer gets = Fee * 20% (если есть)
   * Treasury gets = Fee * 80%
   * Seller gets = SalePrice
   */
  static calculateSecondaryDistribution(
    salePrice: bigint,
    hasReferrer: boolean
  ): FeeDistributionResult {
    if (salePrice <= 0n) {
      throw new Error('Sale price must be positive');
    }

    // Расчет общей комиссии (5% от цены продажи)
    // Примечание: В смарт-контрактах обычно комиссия считается от итоговой суммы или от базы.
    // Согласно WP: "5% tax is levied on every secondary sale". Обычно это % от суммы перевода продавцу.
    const totalFee = (salePrice * BigInt(SECONDARY_SALE_FEE_PERCENT)) / 100n;

    let referrerReward = 0n;
    
    // Расчет доли казны и реферера
    if (hasReferrer) {
      // 20% от комиссии
      referrerReward = (totalFee * BigInt(REFERRER_SHARE_OF_FEE_PERCENT)) / 100n;
    }

    // Остаток комиссии идет в казну (включая часть, которая не ушла рефереру, если его нет)
    const treasuryShare = totalFee - referrerReward;

    const buyerPays = salePrice + totalFee;

    return {
      sellerReceives: salePrice,
      treasuryShare,
      referrerReward,
      totalFee,
      buyerPays,
    };
  }

  /**
   * Рассчитать потенциальную награду Alepe (1% от текущего баланса казны)
   */
  static calculateAlepeReward(treasuryBalance: bigint): bigint {
    return (treasuryBalance * BigInt(1)) / 100n;
  }
}
import { MerkleVerifier } from '../data/merkleVerifier';
import { chunkCache } from '../data/chunkCache';
import { ChunkInfo } from '../contracts/types';

describe('Data Integrity & Reconstruction (Whitepaper Sec 3.3 & 7.1)', () => {
  
  it('should generate consistent Merkle Root for same state', () => {
    const chunks: Record<number, ChunkInfo> = {
      0: { ownerId: '0xA', colorIndex: 1, lastUpdatedBlock: 10n },
      1: { ownerId: '0xB', colorIndex: 2, lastUpdatedBlock: 11n },
    };

    const root1 = MerkleVerifier.computeMerkleRoot(chunks);
    const root2 = MerkleVerifier.computeMerkleRoot(chunks);

    expect(root1).toBe(root2);
  });

  it('should detect changes in chunk state via Merkle Root', () => {
    const chunksA: Record<number, ChunkInfo> = {
      0: { ownerId: '0xA', colorIndex: 1, lastUpdatedBlock: 10n },
    };
    
    const chunksB: Record<number, ChunkInfo> = {
      0: { ownerId: '0xA', colorIndex: 5, lastUpdatedBlock: 10n }, // Color changed
    };

    const rootA = MerkleVerifier.computeMerkleRoot(chunksA);
    const rootB = MerkleVerifier.computeMerkleRoot(chunksB);

    expect(rootA).not.toBe(rootB);
  });

  it('should verify integrity successfully when roots match', () => {
    const localRoot = 'abc123...';
    const onChainRoot = 'ABC123...'; // Case insensitive check

    expect(MerkleVerifier.verifyIntegrity(localRoot, onChainRoot)).toBe(true);
  });

  it('should fail verification when roots mismatch', () => {
    const localRoot = 'abc123';
    const onChainRoot = 'xyz789';

    expect(MerkleVerifier.verifyIntegrity(localRoot, onChainRoot)).toBe(false);
  });
});
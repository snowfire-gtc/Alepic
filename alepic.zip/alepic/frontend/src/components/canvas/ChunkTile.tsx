import React, { memo, useMemo } from 'react'
import { TouchableOpacity } from 'react-native'
import FastImage from 'react-native-fast-image'
import { decodePixelData } from '../../utils/pixelCodec'
import { PALETTE } from '../../utils/colors'
import { chunkIdToCoords } from '../../utils/chunkMath'

interface Props {
  chunkId: string
  data?: { owner: string; pixelData: Uint8Array }
  onPress?: () => void
}

export const ChunkTile = memo(({ chunkId, data, onPress }: Props) => {
  const { x, y } = chunkIdToCoords(chunkId)
  const position = { left: x * 16, top: y * 16 }
  
  // Кэшируем отрисовку чанка как изображение
  const source = useMemo(() => {
    if (!data?.pixelData) {
      // Placeholder для незанятого чанка
      return { uri: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAEklEQVQ4jWNgYGD4z0AHwFgqS1gGAPr2FAF8vq7lAAAAAElFTkSuQmCC' }
    }
    
    // Декодируем 4-bit палитру в изображение 16×16
    const pixels = decodePixelData(data.pixelData)
    // Создаём data:URL для FastImage (в реальном проекте лучше использовать canvas или native модуль)
    const canvas = document?.createElement('canvas') // только для web
    // ... логика отрисовки ...
    return { uri: 'data:image/png;base64,...' }
  }, [data])
  
  const isOwned = !!data?.owner
  const isMine = data?.owner === 'CURRENT_USER_ADDRESS' // заменить на реальную проверку
  
  return (
    <TouchableOpacity 
      style={[{ position: 'absolute', width: 16, height: 16 }, position]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <FastImage
        style={{ width: 16, height: 16 }}
        source={source}
        resizeMode={FastImage.resizeMode.contain}
      />
      
      {/* Индикатор владения */}
      {isOwned && (
        <View style={{
          position: 'absolute',
          bottom: 0,
          right: 0,
          width: 4,
          height: 4,
          backgroundColor: isMine ? '#00D4AA' : '#e94560',
          borderRadius: 2
        }} />
      )}
    </TouchableOpacity>
  )
})
import { buildTransaction, TransactionResult } from 'alephium-web3';
import { alephium } from 'alephium-web3';
import { PixelChange, ChunkInfo, AlepeState } from './types';
import { logger } from '../utils/logger';

const CONTRACT_ID = process.env.EXPO_PUBLIC_CONTRACT_ADDRESS || '';

export class AlepicContract {
  
  async claimChunk(chunkId: number, referrerAddress?: string): Promise<TransactionResult> {
    const totalClaimed = await this.getTotalClaimedCount(); 
    const priceInAtto = (1n + BigInt(totalClaimed)) * 10n**18n;

    const account = await alephium.wallet.getSelectedAccount();
    if (!account) throw new Error("Wallet not connected");

    const referrerArg = referrerAddress ? `Some(Address('${referrerAddress}'))` : 'None';

    const txBuilder = buildTransaction({
      signer: account,
      unsignedTx: {
        scriptCode: `
          use AlepicMain::AlepicMain;
          targetContractId = '${CONTRACT_ID}'
          fn main() {
            AlepicMain(targetContractId).claimChunk(${BigInt(chunkId)}, ${referrerArg})
          }
        `,
        attoAlphAmount: priceInAtto.toString(),
      },
    });

    const signedTx = await alephium.wallet.signTransaction(txBuilder);
    return alephium.client.transactions.submit(signedTx);
  }

  async batchUpdatePixels(changes: PixelChange[], referrerAddress?: string): Promise<TransactionResult> {
    if (changes.length === 0) throw new Error("No changes");

    const formattedChanges = changes.map(c => 
      `PixelChange{chunkId: ${BigInt(c.chunkId)}, pixelIndex: ${BigInt(c.pixelIndex)}, color: ${BigInt(c.colorIndex)}}`
    ).join(', ');

    const account = await alephium.wallet.getSelectedAccount();
    if (!account) throw new Error("Wallet not connected");

    const txBuilder = buildTransaction({
      signer: account,
      unsignedTx: {
        scriptCode: `
          use AlepicMain::PixelChange;
          use AlepicMain::AlepicMain;
          targetContractId = '${CONTRACT_ID}'
          fn main() {
            let changes = [${formattedChanges}];
            AlepicMain(targetContractId).batchUpdatePixels(changes);
          }
        `,
        attoAlphAmount: '0', 
      },
    });

    const signedTx = await alephium.wallet.signTransaction(txBuilder);
    return alephium.client.transactions.submit(signedTx);
  }

  async getChunkInfo(chunkId: number): Promise<ChunkInfo> {
    const instance = alephium.contract.getContractInstance(CONTRACT_ID);
    // Assuming the view returns necessary fields including pixelData
    const result = await instance.views.getChunkInfo({ chunkId: BigInt(chunkId) });
    return {
      ownerId: result.ownerId === '0000...' ? null : result.ownerId,
      pixelData: result.pixelData ? Uint8Array.from(result.pixelData) : null,
      lastUpdatedBlock: result.lastUpdatedBlock,
    };
  }

  async getAlepeState(): Promise<AlepeState> {
    const instance = alephium.contract.getContractInstance(CONTRACT_ID);
    const result = await instance.views.getAlepeState({});
    return {
      x: Number(result.x),
      y: Number(result.y),
      nextJumpBlock: result.nextJumpBlock,
      treasuryBalance: result.treasuryBalance,
      sessionStartBlock: result.sessionStartBlock || 0n,
    };
  }

  private async getTotalClaimedCount(): Promise<number> {
    const instance = alephium.contract.getContractInstance(CONTRACT_ID);
    const res = await instance.views.getTotalClaimedChunks({});
    return Number(res.count);
  }
}

export const contractService = new AlepicContract();
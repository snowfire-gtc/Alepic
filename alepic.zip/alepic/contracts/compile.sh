./scripts/generate-abi.sh
# Убедитесь, что компиляция прошла без ошибок warnings regarding U256 arithmetic
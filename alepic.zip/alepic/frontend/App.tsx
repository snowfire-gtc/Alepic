import 'react-native-get-random-values'; // Полифилл для криптографии
import { useEffect } from 'react';
import { Slot } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { storageService } from './src/services/storageService';

export default function App() {
  useEffect(() => {
    // Предварительная загрузка шрифтов или ресурсов при необходимости
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light" backgroundColor="#000000" />
        <Slot />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
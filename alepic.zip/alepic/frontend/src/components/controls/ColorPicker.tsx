import React from 'react';
import { View, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { colorIndexToHex } from '../../utils/formatters';

// 4-bit палитра (16 цветов)
const PALETTE_INDICES = Array.from({ length: 16 }, (_, i) => i);

interface ColorPickerProps {
  selectedColorIndex: number;
  onSelectColor: (index: number) => void;
}

export const ColorPicker: React.FC<ColorPickerProps> = ({
  selectedColorIndex,
  onSelectColor,
}) => {
  return (
    <View style={styles.container}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {PALETTE_INDICES.map((index) => {
          const color = colorIndexToHex(index);
          const isSelected = selectedColorIndex === index;

          return (
            <TouchableOpacity
              key={index}
              style={[
                styles.colorBox,
                { backgroundColor: color },
                isSelected && styles.selectedBox,
              ]}
              onPress={() => onSelectColor(index)}
              activeOpacity={0.8}
            >
              {isSelected && (
                <View style={styles.checkmark}>
                  {/* Иконка галочки или просто белая рамка */}
                  <View style={styles.innerCheck} />
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>
      <View style={styles.labelContainer}>
        <Text style={styles.label}>Select Color (4-bit)</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    borderRadius: 20,
    padding: 15,
    alignItems: 'center',
  },
  scrollContent: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 5,
  },
  colorBox: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 5,
  },
  selectedBox: {
    borderColor: '#FFFFFF',
    transform: [{ scale: 1.1 }],
    zIndex: 10,
  },
  checkmark: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  innerCheck: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#FFF',
  },
  labelContainer: {
    marginTop: 10,
  },
  label: {
    color: '#AAA',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
});
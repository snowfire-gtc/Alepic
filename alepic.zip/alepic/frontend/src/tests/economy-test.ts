import { FeeCalculator } from '../economy/feeCalculator';
import { BASE_PRICE_ALPH, PRICE_INCREMENT_ALPH, TOTAL_CHUNKS } from '../economy/constants';

describe('Economy Module (Whitepaper Sec 6.1 & 6.2)', () => {
  
  describe('Initial Claim Pricing', () => {
    it('should calculate correct price for the first chunk (1 ALPH)', () => {
      const result = FeeCalculator.calculateInitialClaimPrice(0);
      expect(result.price).toBe(BASE_PRICE_ALPH); // 1n
      expect(result.goesToTreasury).toBe(BASE_PRICE_ALPH);
    });

    it('should increase price by 1 ALPH for each subsequent claim', () => {
      const claimedCount = 100;
      const expectedPrice = BASE_PRICE_ALPH + BigInt(claimedCount) * PRICE_INCREMENT_ALPH;
      
      const result = FeeCalculator.calculateInitialClaimPrice(claimedCount);
      expect(result.price).toBe(expectedPrice); // 101n
    });

    it('should throw error if all chunks are claimed', () => {
      expect(() => FeeCalculator.calculateInitialClaimPrice(TOTAL_CHUNKS)).toThrow('Invalid claimed count');
    });
  });

  describe('Secondary Sale Fee Distribution', () => {
    const salePrice = BigInt(100 * 1e18); // 100 ALPH in attoAlph

    it('should calculate 5% total fee on secondary sale', () => {
      const dist = FeeCalculator.calculateSecondaryDistribution(salePrice, false);
      const expectedFee = (salePrice * 5n) / 100n;
      
      expect(dist.totalFee).toBe(expectedFee);
      expect(dist.buyerPays).toBe(salePrice + expectedFee);
    });

    it('should split fee 80/20 between Treasury and Referrer when referrer exists', () => {
      const dist = FeeCalculator.calculateSecondaryDistribution(salePrice, true);
      
      // Total Fee = 5 ALPH
      // Referrer gets 20% of Fee = 1 ALPH (1% of sale)
      // Treasury gets 80% of Fee = 4 ALPH (4% of sale)
      
      expect(dist.referrerReward).toBe((dist.totalFee * 20n) / 100n);
      expect(dist.treasuryShare).toBe((dist.totalFee * 80n) / 100n);
      expect(dist.sellerReceives).toBe(salePrice); // Seller gets full sale price, fee is added on top
    });

    it('should give 100% of fee to Treasury if no referrer', () => {
      const dist = FeeCalculator.calculateSecondaryDistribution(salePrice, false);
      expect(dist.referrerReward).toBe(0n);
      expect(dist.treasuryShare).toBe(dist.totalFee);
    });
  });
});
import { renderHook, act, waitFor } from '@testing-library/react-native';
import { useChunkData } from '../useChunkData';
import { chunkCache } from '../../data/chunkCache';
import { nodeService } from '../../services/nodeService';
import { ChunkInfo } from '../../contracts/types';

// Моки зависимостей
jest.mock('../../data/chunkCache', () => ({
  chunkCache: {
    get: jest.fn(),
    getMany: jest.fn(),
    setMany: jest.fn(),
    updateSyncHeight: jest.fn(),
    initialize: jest.fn(),
    isInitialized: true,
  },
}));

jest.mock('../../services/nodeService', () => ({
  nodeService: {
    fetchContractEvents: jest.fn(),
    getCurrentBlockHeight: jest.fn(),
  },
}));

jest.mock('../../config/network', () => ({
  networkManager: {
    getConfig: () => ({ id: 'testnet' }),
    getProvider: () => ({}),
  },
}));

describe('useChunkData Hook', () => {
  const mockChunkId = 1001;
  const mockChunkData: ChunkInfo = {
    ownerId: '0xOwnerAddress123',
    colorIndex: 5,
    lastUpdatedBlock: 5000n,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    // Сброс состояния кэша для каждого теста
    (chunkCache.get as jest.Mock).mockReset();
    (chunkCache.getMany as jest.Mock).mockReset();
    (chunkCache.setMany as jest.Mock).mockReset();
  });

  describe('Reading Data', () => {
    it('should return undefined if chunk is not in cache', () => {
      (chunkCache.get as jest.Mock).mockReturnValue(undefined);
      
      const { result } = renderHook(() => useChunkData());
      
      expect(result.current.getChunk(mockChunkId)).toBeUndefined();
      expect(chunkCache.get).toHaveBeenCalledWith(mockChunkId);
    });

    it('should return chunk data immediately if present in cache', () => {
      (chunkCache.get as jest.Mock).mockReturnValue(mockChunkData);
      
      const { result } = renderHook(() => useChunkData());
      
      const data = result.current.getChunk(mockChunkId);
      expect(data).toEqual(mockChunkData);
      expect(data?.colorIndex).toBe(5);
    });

    it('should return multiple chunks via getMany', () => {
      const ids = [1, 2, 3];
      const mockMap = new Map([
        [1, { ...mockChunkData, colorIndex: 1 }],
        [2, { ...mockChunkData, colorIndex: 2 }],
        // Чанк 3 отсутствует
      ]);
      (chunkCache.getMany as jest.Mock).mockReturnValue(mockMap);

      const { result } = renderHook(() => useChunkData());
      const retrieved = result.current.getMany(ids);

      expect(chunkCache.getMany).toHaveBeenCalledWith(ids);
      expect(retrieved.size).toBe(2);
      expect(retrieved.has(1)).toBe(true);
      expect(retrieved.has(3)).toBe(false);
    });
  });

  describe('Fetching Missing Data (Lazy Loading)', () => {
    it('should fetch from network only missing chunks', async () => {
      // Сценарий: Чанк 1 есть в кэше, Чанк 2 нет
      (chunkCache.get)
        .mockReturnValueOnce(mockChunkData) // Для ID 1
        .mockReturnValueOnce(undefined);    // Для ID 2

      // Мок ответа от сети для отсутствующего чанка
      const networkResponse: Record<number, ChunkInfo> = {
        2: { ownerId: null, colorIndex: 0, lastUpdatedBlock: 100n },
      };
      
      // Эмулируем внутреннюю логику fetchMissingChunks через syncRange
      // В реальной реализации хук вызывает nodeService
      (nodeService.fetchContractEvents as jest.Mock).mockResolvedValue([]); 
      // Для упрощения теста, мы будем проверять вызов setMany напрямую после имитации загрузки
      
      const { result } = renderHook(() => useChunkData());

      await act(async () => {
        // Имитируем ручную загрузку (в реальном приложении это триггерится эффектом видимости)
        await result.current.syncRange(2, 2); 
      });

      // Проверяем, что данные были записаны в кэш
      expect(chunkCache.setMany).toHaveBeenCalled();
      const callArg = (chunkCache.setMany as jest.Mock).mock.calls[0][0];
      expect(callArg).toHaveProperty('2');
    });

    it('should set loading state while fetching', async () => {
      (chunkCache.get).mockReturnValue(undefined);
      
      const { result } = renderHook(() => useChunkData());

      let fetchPromise: Promise<void>;
      await act(async () => {
        fetchPromise = result.current.syncRange(10, 20);
        // Сразу после вызова должен быть loading
        expect(result.current.isLoading).toBe(true);
        await fetchPromise;
      });

      expect(result.current.isLoading).toBe(false);
    });

    it('should handle network errors and set error state', async () => {
      (chunkCache.get).mockReturnValue(undefined);
      (nodeService.fetchContractEvents as jest.Mock).mockRejectedValue(new Error('Network Timeout'));

      const { result } = renderHook(() => useChunkData());

      await act(async () => {
        try {
          await result.current.syncRange(5, 5);
        } catch (e) {
          // Ошибка может быть обработана внутри
        }
      });

      // В зависимости от реализации, ошибка либо в стейте, либо логгируется
      // Проверим, что loading сбросился
      expect(result.current.isLoading).toBe(false);
      // Если хук выставляет ошибку в стейт:
      // expect(result.current.error).toContain('Network Timeout');
    });
  });

  describe('Refresh Logic', () => {
    it('should force refresh a single chunk', async () => {
      const { result } = renderHook(() => useChunkData());

      await act(async () => {
        await result.current.refreshChunk(mockChunkId);
      });

      expect(chunkCache.setMany).toHaveBeenCalled();
    });
  });
});
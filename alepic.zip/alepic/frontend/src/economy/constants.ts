import { ALPH } from 'alephium-web3';

// --- Раздел 6.1: Динамическое ценообразование ---
export const BASE_PRICE_ALPH = 1n; // Начальная цена первого чанка
export const PRICE_INCREMENT_ALPH = 1n; // Шаг увеличения цены
export const TOTAL_CHUNKS = 34560; // Общее количество чанков (256 * 135)

// --- Раздел 6.2: Система комиссий и Казна ---
// Комиссия за вторичную продажу (платит покупатель сверх цены)
export const SECONDARY_SALE_FEE_PERCENT = 5; // 5%

// Распределение комиссии от вторичной продажи:
// 20% от комиссии идет рефереру (итого 1% от суммы сделки)
export const REFERRER_SHARE_OF_FEE_PERCENT = 20; 
// 80% от комиссии идет в Казну (итого 4% от суммы сделки)
export const TREASURY_SHARE_OF_FEE_PERCENT = 80; 

// Награды Alepe (Раздел 4 и 6.3)
// Алепе забирает 1% от баланса Казны при успешном прыжке на занятый чанк
export const ALEPE_REWARD_TREASURY_PERCENT = 1; 

// Конвертация для удобства (1 ALPH = 10^18 attoAlph)
export const ONE_ALPH = ALPH; 
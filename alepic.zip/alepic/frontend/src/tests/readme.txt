.  **Юнит-тесты и интеграционные:** `npm run test`
2.  **Покрытие кода:** `npm run test:coverage` (покажет, какие модули еще требуют тестов).
3.  **E2E (требуется симулятор):** `npm run test:e2e`

Этот набор тестов покрывает критические пути: экономику (деньги), игру (вовлечение)...




add to package.json:

{
  "scripts": {
    "test": "jest",
    "test:watch": "jest --watch",
    "test:coverage": "jest --coverage",
    "test:e2e": "detox test --configuration ios.sim.debug",
    "lint": "eslint src/",
    "type-check": "tsc --noEmit"
  },
  "jest": {
    "preset": "jest-expo",
    "collectCoverageFrom": [
      "src/**/*.{ts,tsx}",
      "!src/**/*.d.ts",
      "!src/**/__tests__/**"
    ],
    "coverageThreshold": {
      "global": {
        "branches": 70,
        "functions": 70,
        "lines": 70,
        "statements": 70
      }
    }
  }
}
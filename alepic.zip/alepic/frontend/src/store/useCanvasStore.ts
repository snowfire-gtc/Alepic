import { create } from 'zustand'
import { ChunkData, AlepeState } from '../types'

interface CanvasState {
  // Данные чанков: chunkId → данные
  chunks: Map<string, ChunkData>
  
  // Состояние игры Alepe
  alepe: AlepeState
  
  // UI-состояние
  viewport: { x: number; y: number; zoom: number }
  selectedChunk: string | null
  isEditing: boolean
  
  // Actions
  setChunk: (chunkId: string, data: ChunkData) => void
  setAlepe: (state: AlepeState) => void
  setViewport: (viewport: { x: number; y: number; zoom: number }) => void
  selectChunk: (chunkId: string | null) => void
  toggleEditing: (value?: boolean) => void
  
  // Вычисляемые значения
  getVisibleChunks: () => string[]
}

export const useCanvasStore = create<CanvasState>((set, get) => ({
  chunks: new Map(),
  alepe: { x: 2048, y: 1080, lastJumpBlock: 0 },
  viewport: { x: 0, y: 0, zoom: 1 },
  selectedChunk: null,
  isEditing: false,
  
  setChunk: (chunkId, data) => set(state => {
    const newChunks = new Map(state.chunks)
    newChunks.set(chunkId, data)
    return { chunks: newChunks }
  }),
  
  setAlepe: (alepe) => set({ alepe }),
  
  setViewport: (viewport) => set({ viewport }),
  
  selectChunk: (chunkId) => set({ selectedChunk: chunkId }),
  
  toggleEditing: (value) => set({ isEditing: value ?? !get().isEditing }),
  
  getVisibleChunks: () => {
    const { viewport } = get()
    const { x, y, zoom } = viewport
    const visible: string[] = []
    
    // Рассчитываем, какие чанки попадают в видимую область
    // 4096×2160 canvas, чанки 16×16 → 256×135 сетка
    const startChunkX = Math.max(0, Math.floor((x / zoom) / 16) - 2)
    const endChunkX = Math.min(256, Math.ceil(((x / zoom) + 4096) / 16) + 2)
    const startChunkY = Math.max(0, Math.floor((y / zoom) / 16) - 2)
    const endChunkY = Math.min(135, Math.ceil(((y / zoom) + 2160) / 16) + 2)
    
    for (let cy = startChunkY; cy < endChunkY; cy++) {
      for (let cx = startChunkX; cx < endChunkX; cx++) {
        const chunkId = `${cy * 256 + cx}`
        visible.push(chunkId)
      }
    }
    return visible
  }
}))
import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Dimensions, Text, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';

import { AlepicCanvas } from '../components/canvas/AlepicCanvas';
import { AlepeOverlay } from '../components/canvas/AlepeOverlay';
import { useAlepeState } from '../hooks/useAlepeState';
import { useVisibleChunks } from '../hooks/useVisibleChunks';
import { storageService } from '../services/storageService';
import { DEFAULT_BILLBOARD_PROFILES, BillboardProfile } from '../config/billboardConfig';
import { PinPadModal } from '../components/ui/PinPadModal';
import { logger } from '../utils/logger';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export default function BillboardScreen() {
  const router = useRouter();
  const { state: alepeState } = useAlepeState();
  
  const [profile, setProfile] = useState<BillboardProfile | null>(null);
  const [showExitPin, setShowExitPin] = useState(false);

  useEffect(() => {
    initBillboard();
    return () => {
      deactivateKeepAwake(); // Разрешаем сон при выходе
    };
  }, []);

  const initBillboard = async () => {
    try {
      await activateKeepAwakeAsync();
      logger.info('Billboard', 'Keep Awake activated');

      const status = await storageService.getBillboardStatus();
      const selectedProfile = DEFAULT_BILLBOARD_PROFILES.find(p => p.id === status.profileId) || DEFAULT_BILLBOARD_PROFILES[0];
      
      let finalZoom = selectedProfile.zoomLevel;
      let offsetX = selectedProfile.offsetX;
      let offsetY = selectedProfile.offsetY;

      if (selectedProfile.fitToScreen) {
        finalZoom = SCREEN_WIDTH / 4096;
        const scaledHeight = 2160 * finalZoom;
        offsetY = scaledHeight < SCREEN_HEIGHT ? (SCREEN_HEIGHT - scaledHeight) / 2 : 0;
        offsetX = 0;
      }

      setProfile({ ...selectedProfile, zoomLevel: finalZoom, offsetX, offsetY });
      logger.info('Billboard', `Profile loaded: ${selectedProfile.name}`);
    } catch (error) {
      logger.error('Billboard', 'Initialization failed', error);
    }
  };

  const handleExitRequest = () => {
    if (profile?.requirePinToExit) {
      setShowExitPin(true);
    } else {
      exitBillboardMode();
    }
  };

  const exitBillboardMode = async () => {
    await storageService.setBillboardMode(false);
    router.replace('/');
  };

  if (!profile) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Initializing Billboard...</Text>
      </View>
    );
  }

  const visibleChunks = useVisibleChunks(profile.zoomLevel, profile.offsetX, profile.offsetY);

  return (
    <View style={styles.container}>
      <AlepicCanvas
        zoom={profile.zoomLevel}
        offset={{ x: profile.offsetX, y: profile.offsetY }}
        onOffsetChange={() => {}}
        visibleChunkIds={visibleChunks}
        onChunkPress={() => {}}
        onChunkLongPress={() => {}}
        readOnly={true}
        isBillboardMode={true}
      />

      {alepeState && (
        <AlepeOverlay
          x={alepeState.x}
          y={alepeState.y}
          zoom={profile.zoomLevel}
          offset={{ x: profile.offsetX, y: profile.offsetY }}
          screenWidth={SCREEN_WIDTH}
          screenHeight={SCREEN_HEIGHT}
        />
      )}

      <View style={styles.statusBar}>
        <View style={styles.statusDot} />
        <Text style={styles.statusText}>LIVE • {profile.name}</Text>
      </View>

      <TouchableOpacity style={styles.exitZone} onPress={handleExitRequest}>
        <Text style={styles.exitText}>EXIT</Text>
      </TouchableOpacity>

      <PinPadModal
        visible={showExitPin}
        onClose={() => setShowExitPin(false)}
        onSuccess={exitBillboardMode}
        title="Admin Authorization"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#FFF' },
  statusBar: {
    position: 'absolute', top: 10, left: 10, flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16
  },
  statusDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#00FF00', marginRight: 8 },
  statusText: { color: '#FFF', fontSize: 11, fontWeight: '700' },
  exitZone: { position: 'absolute', bottom: 10, right: 10, padding: 12, backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 8 },
  exitText: { color: 'rgba(255,255,255,0.2)', fontSize: 10, fontWeight: 'bold' },
});
// Соответствует структурам в смарт-контракте Alepic.alu v7.0

export interface ChunkInfo {
  ownerId: string | null;
  // Массив из 128 байт, представляющих 256 пикселей (4 бита на пиксель)
  // В JS представляем как Uint8Array или числовой массив 0-255
  pixelData: Uint8Array | null; 
  lastUpdatedBlock: bigint;
}

export interface PixelChange {
  chunkId: number;      // ID чанка
  pixelIndex: number;   // 0..255 (индекс пикселя внутри чанка)
  colorIndex: number;   // 0..15 (цвет из палитры)
}

export interface AlepeState {
  x: number;
  y: number;
  nextJumpBlock: bigint;
  treasuryBalance: bigint;
  sessionStartBlock: bigint;
}

export interface ContractState {
  totalClaimedChunks: number;
  nextClaimPrice: bigint;
  merkleRoot: string;
}
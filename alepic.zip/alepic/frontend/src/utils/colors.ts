// 4-bit палитра: 16 предустановленных цветов (HEX)
export const PALETTE = [
  '#000000', // 0: Black
  '#1a1a2e', // 1: Dark Blue
  '#16213e', // 2: Navy
  '#0f3460', // 3: Deep Blue
  '#533483', // 4: Purple
  '#e94560', // 5: Alepe Red
  '#ff6b6b', // 6: Coral
  '#ffa502', // 7: Orange
  '#ffd32a', // 8: Yellow
  '#00d4aa', // 9: Alephium Teal
  '#4ecdc4', // 10: Mint
  '#45b7d1', // 11: Sky Blue
  '#96ceb4', // 12: Sage
  '#a8e6cf', // 13: Light Green
  '#dcedc1', // 14: Lime
  '#ffffff', // 15: White
] as const
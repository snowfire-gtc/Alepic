import { Stack } from 'expo-router';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { notificationService } from '../services/notificationService';
import { appController } from '../AppController';

export default function RootLayout() {
  useEffect(() => {
    // Инициализация уведомлений и фоновых процессов
    notificationService.initialize();
    appController.start();
    
    return () => appController.stop();
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light" backgroundColor="#000000" />
        <Stack screenOptions={{ 
          headerStyle: { backgroundColor: '#000' },
          headerTintColor: '#fff',
          contentStyle: { backgroundColor: '#000' }
        }}>
          <Stack.Screen name="index" options={{ title: 'Alepic Canvas', headerShown: false }} />
          <Stack.Screen name="dashboard" options={{ title: 'Dashboard' }} />
          <Stack.Screen name="marketplace" options={{ title: 'Marketplace' }} />
          <Stack.Screen name="billboard" options={{ title: 'Billboard Mode', headerShown: false }} />
          <Stack.Screen name="settings" options={{ title: 'Settings' }} />
          <Stack.Screen name="chunk/[id]" options={{ title: 'Chunk Details' }} />
        </Stack>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
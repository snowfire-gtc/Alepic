// hooks/useVisibleChunks.ts
import { useMemo } from 'react';
import { viewportWidth, viewportHeight, chunkSize } from '../constants';

const TOTAL_CHUNKS_X = 256;
const TOTAL_CHUNKS_Y = 135;
const CHUNK_SIZE = 16; // пикселей

export const useVisibleChunks = (zoomLevel: number, offsetX: number, offsetY: number) => {
  return useMemo(() => {
    // Расчет границ видимой области в пикселях холста
    const visiblePixelLeft = Math.max(0, -offsetX / zoomLevel);
    const visiblePixelTop = Math.max(0, -offsetY / zoomLevel);
    const visiblePixelRight = Math.min(4096, (viewportWidth - offsetX) / zoomLevel);
    const visiblePixelBottom = Math.min(2160, (viewportHeight - offsetY) / zoomLevel);

    // Перевод в координаты чанков
    const startChunkX = Math.floor(visiblePixelLeft / CHUNK_SIZE);
    const startChunkY = Math.floor(visiblePixelTop / CHUNK_SIZE);
    const endChunkX = Math.ceil(visiblePixelRight / CHUNK_SIZE);
    const endChunkY = Math.ceil(visiblePixelBottom / CHUNK_SIZE);

    const chunksToLoad = [];

    for (let x = startChunkX; x < endChunkX; x++) {
      for (let y = startChunkY; y < endChunkY; y++) {
        if (x >= 0 && x < TOTAL_CHUNKS_X && y >= 0 && y < TOTAL_CHUNKS_Y) {
          const chunkId = y * TOTAL_CHUNKS_X + x;
          chunksToLoad.push({ id: chunkId, x, y });
        }
      }
    }

    return chunksToLoad;
  }, [zoomLevel, offsetX, offsetY]);
};
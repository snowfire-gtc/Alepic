import { web3 } from '@alephium/web3'
import { getSigner } from '@alephium/web3-test'
import { Alepic } from '../artifacts/ts'

describe('Alepic Contract', () => {
  it('should claim chunk with correct price', async () => {
    web3.setCurrentNodeProvider('http://127.0.0.1:22973')
    const signer = await getSigner()
    
    const alepic = await Alepic.deploy(signer, {
      initialFields: {
        nextChunkPrice: 1_000_000_000n,
        treasuryBalance: 0n,
        alepeX: 2048n,
        alepeY: 1080n,
        lastJumpBlock: 0n
      }
    })
    
    const result = await alepic.contractInstance.transact.claimChunk({
      signer,
      args: { chunkId: 0n, referrer: undefined },
      attoAlphAmount: 1_000_000_000n
    })
    
    expect(result.events).toContainEqual(
      expect.objectContaining({ name: 'ChunkClaimed' })
    )
  })
})
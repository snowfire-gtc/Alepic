import React, { useMemo, useRef } from 'react';
import { Canvas, Rect, Image, useImage } from '@shopify/react-native-skia';
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native';
import { usePixelDrawer } from '../../hooks/usePixelDrawer';
import { getColorByIndex, getPaletteUint8Array } from '../../data/palette';
import { chunkIdToPixel } from '../../utils/math';
import { useChunkData } from '../../hooks/useChunkData';
import { Ionicons } from '@expo/vector-icons';
import { makeImageFromEncoded } from '@shopify/react-native-skia'; // Или соответствующий API вашей версии Skia
import { decompressChunkToRGBA } from '../../utils/imageProcessor';

const CHUNK_SIZE_PX = 16;

interface AlepicCanvasProps {
  zoom: number;
  offset: { x: number; y: number };
  visibleChunkIds: number[];
  selectedColor: number;
  isOwnerMode: boolean; //true если пользователь владеет видимыми чанками
}

export const AlepicCanvas: React.FC<AlepicCanvasProps> = ({
  zoom,
  offset,
  visibleChunkIds,
  selectedColor,
  isOwnerMode,
}) => {
  const { getMany } = useChunkData();
  const { pendingCount, handlers, submitChanges } = usePixelDrawer(isOwnerMode);
  
  // Кэш текстур чанков (оптимизация: создаем текстуру 16x16 для каждого чанка)
  const chunkTextures = useMemo(() => {
    const textures: Record<number, any> = {}; // В реальном проекте использовать Skia Image
    const chunks = getMany(visibleChunkIds);
    
    chunks.forEach((info, id) => {
      if (info.pixelData) {
        // Декодирование Uint8Array (128 байт) в массив цветов для рендеринга
        // Здесь должна быть логика создания Skia Image из байтов
        // Для краткости примера оставляем заглушку логики
        textures[id] = info.pixelData; 
      }
    });
    return textures;
  }, [visibleChunkIds, getMany]);

  // Обработчики жестов (упрощенно)
  const handleTouchStart = (e: any) => {
    if (!isOwnerMode) return;
    const { locationX, locationY } = e.nativeEvent;
    const globalX = Math.floor((locationX - offset.x) / zoom);
    const globalY = Math.floor((locationY - offset.y) / zoom);
    handlers.onStart(globalX, globalY, selectedColor);
  };

  const handleTouchMove = (e: any) => {
    if (!isOwnerMode) return;
    const { locationX, locationY } = e.nativeEvent;
    const globalX = Math.floor((locationX - offset.x) / zoom);
    const globalY = Math.floor((locationY - offset.y) / zoom);
    handlers.onMove(globalX, globalY, selectedColor);
  };

  return (
    <View style={styles.container}>
      <Canvas 
        style={StyleSheet.absoluteFill} 
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handlers.onEnd}
      >
        {/* Рендеринг чанков с попиксельной детализацией */}
        {/* Здесь должен быть код отрисовки текстур, сгенерированных из pixelData */}
// ... внутри useMemo или render цикла ...
{visibleChunkIds.map(id => {
   const info = chunks.get(id);
   const pos = chunkIdToPixel(id);
   
   let renderElement = null;

   if (info?.pixelData) {
     // Декомпрессия и создание текстуры на лету
     // Примечание: В продакшене нужно кэшировать объекты Image, чтобы не создавать их каждый кадр
     const rgbaData = decompressChunkToRGBA(info.pixelData);
     
     // Создаем изображение Skia (проверьте API вашей версии, возможно нужен Skia.Image.makeFromPixels)
     // Для примера используем абстракцию:
     const skiaImage = makeImageFromEncoded(rgbaData, 16, 16); 

     if (skiaImage) {
       renderElement = (
         <Image
           key={id}
           image={skiaImage}
           x={pos.x}
           y={pos.y}
           width={CHUNK_SIZE_PX}
           height={CHUNK_SIZE_PX}
           fit="cover"
         />
       );
     }
   }
   
   // Фоллбэк если нет данных или ошибка
   if (!renderElement) {
     renderElement = (
       <Rect
         key={id}
         x={pos.x}
         y={pos.y}
         width={CHUNK_SIZE_PX}
         height={CHUNK_SIZE_PX}
         color="#000000"
       />
     );
   }

   return renderElement;
   })}
      </Canvas>

      {/* Кнопка SEND (появляется только если есть изменения) */}
      {pendingCount > 0 && (
        <View style={styles.sendButtonContainer}>
          <TouchableOpacity 
            style={styles.sendButton} 
            onPress={submitChanges}
            activeOpacity={0.8}
          >
            <Ionicons name="cloud-upload-outline" size={24} color="#000" />
            <Text style={styles.sendButtonText}>
              SEND ({pendingCount})
            </Text>
          </TouchableOpacity>
          <Text style={styles.costHint}>~{(pendingCount * 0.00005).toFixed(5)} ALPH</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  sendButtonContainer: {
    position: 'absolute',
    bottom: 100,
    alignSelf: 'center',
    alignItems: 'center',
  },
  sendButton: {
    flexDirection: 'row',
    backgroundColor: '#00FF00',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 30,
    alignItems: 'center',
    shadowColor: '#00FF00',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 10,
  },
  sendButtonText: {
    color: '#000',
    fontWeight: 'bold',
    fontSize: 16,
    marginLeft: 8,
  },
  costHint: {
    color: '#FFF',
    fontSize: 12,
    marginTop: 4,
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 8,
    borderRadius: 4,
  },
});
#!/bin/bash

# ==============================================================================
# Alepic ABI & Types Generator
# ==============================================================================
# Этот скрипт компилирует смарт-контракт AluX и генерирует необходимые артефакты
# для фронтенд-приложения (React Native/TypeScript).
#
# Требования:
# 1. Установленный Alephium CLI (alfie) или docker-контейнер с ним.
# 2. Node.js окружение для пост-обработки JSON.
#
# Использование:
# ./scripts/generate-abi.sh
# ==============================================================================

set -e # Остановка скрипта при любой ошибке

# --- Конфигурация путей ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
CONTRACTS_SRC_DIR="$ROOT_DIR/contracts/src" # Путь к исходникам .alu
OUTPUT_DIR="$ROOT_DIR/src/contracts"        # Куда сохранять результаты
TEMP_BUILD_DIR="$ROOT_DIR/.tmp_build"       # Временная папка для компиляции

# Имена файлов
CONTRACT_NAME="AlepicMain"
ABI_OUTPUT_FILE="$OUTPUT_DIR/abi.json"
TYPES_OUTPUT_FILE="$OUTPUT_DIR/types.ts"

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🚀 Starting Alepic ABI Generation...${NC}"

# 1. Очистка и подготовка
echo "🧹 Cleaning temporary directories..."
rm -rf "$TEMP_BUILD_DIR"
mkdir -p "$TEMP_BUILD_DIR"
mkdir -p "$OUTPUT_DIR"

# 2. Компиляция контракта (AluX -> Bytecode + ABI)
# Примечание: Команда зависит от версии установленного alephium-cli (alfie)
# Предполагается, что 'alfie' доступен в PATH или используется docker.
echo "🔨 Compiling AluX contracts..."

if command -v alfie &> /dev/null; then
    # Локальная компиляция
    alfie build \
      --input-dir "$CONTRACTS_SRC_DIR" \
      --output-dir "$TEMP_BUILD_DIR" \
      --generate-artifacts
else
    # Компилация через Docker (если alfie не установлен локально)
    echo "⚠️  'alfie' not found locally. Using Docker container..."
    docker run --rm -v "$ROOT_DIR:/project" alephium/alfie:latest \
      build \
      --input-dir /project/contracts/src \
      --output-dir /project/.tmp_build \
      --generate-artifacts
fi

# Проверка успешности компиляции
if [ ! -f "$TEMP_BUILD_DIR/$CONTRACT_NAME.ralfie" ]; then
    echo -e "${RED}❌ Compilation failed. Output artifacts not found.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Contracts compiled successfully.${NC}"

# 3. Извлечение и очистка ABI
echo "📝 Extracting ABI definition..."

# Alephium CLI обычно генерирует файл .ralfie или .json с метаданными.
# Здесь мы эмулируем извлечение JSON части. В реальном сценарии формат может отличаться.
# Предположим, что артефакт содержит JSON структуру внутри.

# Если CLI выдает отдельный JSON файл:
if [ -f "$TEMP_BUILD_DIR/${CONTRACT_NAME}_abi.json" ]; then
    cp "$TEMP_BUILD_DIR/${CONTRACT_NAME}_abi.json" "$ABI_OUTPUT_FILE"
else
    # Эмуляция: создаем базовую структуру, если файл не найден явно (для демонстрации)
    # В реальном проекте здесь используется jq или node-скрипт для парсинга бинарного артефакта
    echo "⚠️  Specific ABI file not found, attempting to parse main artifact..."
    # Здесь должна быть команда типа: jq '.abi' ... > $ABI_OUTPUT_FILE
    
    # Для примера создадим заглушку, если парсинг не реализован в bash
    cat > "$ABI_OUTPUT_FILE" <<EOL
{
  "version": "7.0",
  "contractName": "$CONTRACT_NAME",
  "note": "This file is auto-generated. Do not edit manually.",
  "generatedAt": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "functions": [], 
  "views": [],
  "warning": "Placeholder: Real ABI extraction requires specific CLI flags or Node.js post-processing script."
}
EOL
fi

# 4. Генерация TypeScript типов (Node.js пост-процессинг)
echo "💻 Generating TypeScript interfaces..."

node - "$ABI_OUTPUT_FILE" "$TYPES_OUTPUT_FILE" <<'NODE_SCRIPT'
const fs = require('fs');
const path = require('path');

const [,, abiInputPath, typesOutputPath] = process.argv;

try {
  const abiData = JSON.parse(fs.readFileSync(abiInputPath, 'utf8'));
  
  let tsContent = `/**
 * AUTO-GENERATED TYPES FOR ALEPIC CONTRACT
 * Source: ${abiData.contractName}
 * Generated at: ${new Date().toISOString()}
 * DO NOT EDIT MANUALLY
 */

`;

  // Генерация интерфейсов для структур данных (Structs)
  // В реальном ABI будут поля structs, здесь эмулируем основные типы из Whitepaper
  tsContent += `// --- Core Data Structures ---\n\n`;
  
  tsContent += `export interface ChunkInfo {
  ownerId: string | null; // Address or null
  colorIndex: number;     // 0-15 (4-bit palette)
  lastUpdatedBlock: bigint;
}\n\n`;

  tsContent += `export interface AlepeState {
  x: number;
  y: number;
  nextJumpBlock: bigint;
  treasuryBalance: bigint;
  sessionStartBlock: bigint;
}\n\n`;

  tsContent += `export interface ContractState {
  totalClaimedChunks: number;
  nextClaimPrice: bigint;
  merkleRoot: string;
}\n\n`;

  // Генерация типов аргументов функций на основе ABI (если данные есть)
  if (abiData.functions && Array.isArray(abiData.functions)) {
    tsContent += `// --- Function Arguments ---\n\n`;
    
    abiData.functions.forEach(func => {
      const funcName = func.name.charAt(0).toUpperCase() + func.name.slice(1);
      tsContent += `export interface ${funcName}Args {\n`;
      if (func.args && func.args.length > 0) {
        func.args.forEach(arg => {
          const tsType = mapAluXTypeToTS(arg.type);
          tsContent += `  ${arg.name}: ${tsType};\n`;
        });
      }
      if (func.optionalFields) {
        func.optionalFields.forEach(field => {
          const tsType = mapAluXTypeToTS(field.type);
          tsContent += `  ${field.name}?: ${tsType};\n`;
        });
      }
      tsContent += `}\n\n`;
    });
  }

  // Helper function for type mapping
  function mapAluXTypeToTS(aluType: string): string {
    switch (aluType) {
      case 'Address': return 'string';
      case 'U256': 
      case 'I256': 
      case 'U64': return 'bigint';
      case 'Bool': return 'boolean';
      case 'ByteVec': return 'string'; // Hex string
      default: return 'any';
    }
  }

  fs.writeFileSync(typesOutputPath, tsContent);
  console.log('✅ TypeScript types generated successfully.');

} catch (error) {
  console.error('❌ Error generating TS types:', error);
  process.exit(1);
}
NODE_SCRIPT

# 5. Финализация
echo "📦 Copying artifacts to src/contracts..."
# Дополнительные действия, если нужно скопировать байткод для тестов

# Очистка временных файлов
rm -rf "$TEMP_BUILD_DIR"

echo -e "${GREEN}=================================================================="
echo "✨ Alepic ABI Generation Complete!"
echo "   - ABI: $ABI_OUTPUT_FILE"
echo "   - Types: $TYPES_OUTPUT_FILE"
echo "==================================================================${NC}"
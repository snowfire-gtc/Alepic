import { Configuration } from '@alephium/cli'

type Settings = {
  initialPrice: bigint
  alepeJumpInterval: bigint
}

const configuration: Configuration<Settings> = {
  networks: {
    devnet: {
      nodeUrl: 'http://localhost:22973',
      privateKeys: ['ВАШ_ПРИВАТНЫЙ_КЛЮЧ_ДЛЯ_ТЕСТОВ'],
      confirmations: 1,
      settings: {
        initialPrice: 1_000_000_000n, // 1 ALPH в атто
        alepeJumpInterval: 100_000n
      }
    },
    testnet: {
      nodeUrl: process.env.NODE_URL || 'https://node.testnet.alephium.org',
      privateKeys: process.env.PRIVATE_KEYS?.split(',') || [],
      settings: {
        initialPrice: 1_000_000_000n,
        alepeJumpInterval: 100_000n
      }
    }
  }
}

export default configuration
# Для Testnet
export NODE_URL=https://node.testnet.alephium.org
export PRIVATE_KEYS="ваш_приватный_ключ"
npx @alephium/cli deploy -n testnet

# Для Mainnet (только после аудита!)
# export NODE_URL=https://node.mainnet.alephium.org
# npx @alephium/cli deploy -n mainnet
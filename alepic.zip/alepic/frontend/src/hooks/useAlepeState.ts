import { useState, useEffect } from 'react';
import { contractService } from '../contracts/AlepicContract';
import { AlepeEngine } from '../game/AlepeEngine';
import { AlepeState } from '../contracts/types';

export const useAlepeState = () => {
  const [state, setState] = useState<AlepeState | null>(null);
  const [prediction, setPrediction] = useState<{ timeLeftMs: number, nextJumpBlock: bigint } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    const fetchState = async () => {
      try {
        const alepeState = await contractService.getAlepeState();
        setState(alepeState);
        
        // Получаем текущую высоту блока (упрощенно)
        const currentHeight = await getCurrentBlockHeightMock(); 
        
        const pred = AlepeEngine.predictNextMove(alepeState, currentHeight);
        setPrediction({
          timeLeftMs: pred.timeUntilNextJumpMs,
          nextJumpBlock: pred.nextJumpBlockHeight
        });
      } catch (e) {
        console.error('Failed to fetch Alepe state', e);
      } finally {
        setLoading(false);
      }
    };

    fetchState();
    // Опрос каждые 5 секунд
    interval = setInterval(fetchState, 5000);

    return () => clearInterval(interval);
  }, []);

  return { state, prediction, loading };
};

// Заглушка для получения высоты блока (заменить на реальный вызов RPC)
const getCurrentBlockHeightMock = async () => 123456789n;
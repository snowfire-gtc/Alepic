import { useState, useEffect, useCallback, useRef } from 'react';
import { chunkCache } from '../data/chunkCache';
import { nodeService } from '../services/nodeService';
import { ChunkInfo } from '../contracts/types';
import { logger } from '../utils/logger';
import { networkManager } from '../config/network';

interface UseChunkDataResult {
  getChunk: (chunkId: number) => ChunkInfo | undefined;
  getMany: (chunkIds: number[]) => Map<number, ChunkInfo>;
  isLoading: boolean;
  error: string | null;
  refreshChunk: (chunkId: number) => Promise<void>;
  syncRange: (startId: number, endId: number) => Promise<void>;
}

/**
 * Хук для управления данными чанков с поддержкой ленивой загрузки и кэширования.
 * Реализует логику Dynamic Loading (Раздел 5.2 WP).
 */
export const useChunkData = (): UseChunkDataResult => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Счетчик версий для принудительного ре-рендера при обновлении кэша
  const [cacheVersion, setCacheVersion] = useState(0);
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);

  // Функция получения одного чанка
  const getChunk = useCallback((chunkId: number): ChunkInfo | undefined => {
    return chunkCache.get(chunkId);
  }, [cacheVersion]); // Зависимость от версии кэша

  // Функция пакетного получения чанков
  const getMany = useCallback((chunkIds: number[]): Map<number, ChunkInfo> => {
    return chunkCache.getMany(chunkIds);
  }, [cacheVersion]);

  // Загрузка отсутствующих чанков из сети
  const fetchMissingChunks = async (chunkIds: number[]) => {
    const missingIds: number[] = [];
    
    // Проверка наличия в кэше
    chunkIds.forEach(id => {
      if (!chunkCache.get(id)) {
        missingIds.push(id);
      }
    });

    if (missingIds.length === 0) return;

    setIsLoading(true);
    setError(null);

    try {
      logger.debug('useChunkData', `Fetching ${missingIds.length} missing chunks from network...`);
      
      // В реальной реализации nodeService.fetchChunks должен уметь брать пакет ID
      // Здесь эмулируем последовательную загрузку или пакетный запрос
      const fetchedData: Record<number, ChunkInfo> = {};
      
      // Эмуляция запроса к ноде (в продакшене один вызов API)
      // const response = await nodeService.getChunks(missingIds);
      
      // Для демо: заглушка, которая возвращает пустые чанки или данные из мока
      // В реальном коде здесь будет логика реконструкции из истории блоков
      for (const id of missingIds) {
        // Попытка получить из контракта напрямую (медленно) или из индексатора
        // const info = await nodeService.getChunkState(id); 
        // fetchedData[id] = info;
        
        // ЗАГЛУШКА ДЛЯ ДЕМО: Генерируем случайный цвет, если чанк "не найден" в истории
        // Это нужно только чтобы тестировать UI без реальной ноды
        fetchedData[id] = {
          ownerId: null,
          colorIndex: Math.floor(Math.random() * 16),
          lastUpdatedBlock: 0n
        };
      }

      // Сохранение в кэш (это триггернет обновление подписчиков, если мы реализуем паттерн Observer)
      // Так как chunkCache не является Observable, мы вручную увеличиваем версию
      chunkCache.setMany(fetchedData);
      
      if (isMounted.current) {
        setCacheVersion(prev => prev + 1);
      }

    } catch (err: any) {
      logger.error('useChunkData', 'Failed to fetch chunks', err);
      if (isMounted.current) {
        setError(err.message || 'Network error');
      }
    } finally {
      if (isMounted.current) {
        setIsLoading(false);
      }
    }
  };

  // Публичный метод для принудительного обновления одного чанка
  const refreshChunk = async (chunkId: number) => {
    await fetchMissingChunks([chunkId]);
  };

  // Публичный метод для синхронизации диапазона (например, при скролле)
  const syncRange = async (startId: number, endId: number) => {
    const range: number[] = [];
    for (let i = startId; i <= endId; i++) {
      range.push(i);
    }
    await fetchMissingChunks(range);
  };

  // Эффект для автоматической подгрузки при изменении списка видимых ID
  // Примечание: В реальном приложении список ID передается как аргумент хука или через контекст
  // Здесь мы предоставляем методы, а вызов методов делегируем компоненту Canvas
  
  return {
    getChunk,
    getMany,
    isLoading,
    error,
    refreshChunk,
    syncRange,
  };
};
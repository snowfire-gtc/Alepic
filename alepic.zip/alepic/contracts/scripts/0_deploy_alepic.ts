import { Deployer, DeployFunction, Network } from '@alephium/cli'
import { Settings } from '../alephium.config'
import { Alepic } from '../artifacts/ts'

const deployAlepic: DeployFunction<Settings> = async (
  deployer: Deployer,
  network: Network<Settings>
): Promise<void> => {
  const result = await deployer.deployContract(Alepic, {
    initialFields: {
      nextChunkPrice: network.settings.initialPrice,
      treasuryBalance: 0n,
      alepeX: 2048n,  // Center of 4096px canvas
      alepeY: 1080n,  // Center of 2160px canvas
      lastJumpBlock: 0n
    },
    issueTokenAmount: 0n  // No token issuance, ALPH only
  })
  
  console.log('✅ Alepic deployed!')
  console.log(`Contract ID: ${result.contractInstance.contractId}`)
  console.log(`Address: ${result.contractInstance.address}`)
}

export default deployAlepic
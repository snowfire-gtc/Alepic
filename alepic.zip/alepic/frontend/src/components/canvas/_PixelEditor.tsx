import React, { useState, useCallback } from 'react'
import { Modal, View, TouchableOpacity, Text, Alert } from 'react-native'
import { useAlephium } from '../../hooks/useAlephium'
import { useCanvasStore } from '../../store/useCanvasStore'
import { encodePixelData } from '../../utils/pixelCodec'
import { PALETTE } from '../../utils/colors'

export const PixelEditor = () => {
  const { contract, wallet } = useAlephium()
  const { selectedChunk, chunks, toggleEditing, setChunk } = useCanvasStore()
  const [selectedColor, setSelectedColor] = useState(0)
  const [pixelGrid, setPixelGrid] = useState<Uint8Array>(() => {
    // Загружаем текущие данные чанка или создаём пустые
    const data = selectedChunk ? chunks.get(selectedChunk)?.pixelData : null
    return data || new Uint8Array(128) // 128 байт для 256 пикселей × 4-bit
  })
  
  const handlePixelPress = useCallback((index: number) => {
    setPixelGrid(prev => {
      const newGrid = new Uint8Array(prev)
      // 4-bit: 2 пикселя в 1 байте
      const byteIndex = Math.floor(index / 2)
      const isEven = index % 2 === 0
      
      if (isEven) {
        newGrid[byteIndex] = (selectedColor << 4) | (newGrid[byteIndex] & 0x0F)
      } else {
        newGrid[byteIndex] = (newGrid[byteIndex] & 0xF0) | selectedColor
      }
      return newGrid
    })
  }, [selectedColor])
  
  const handleSave = async () => {
    if (!contract || !wallet || !selectedChunk) return
    
    try {
      const result = await contract.transact.updatePixels({
        signer: wallet,
        args: {
          chunkId: BigInt(selectedChunk),
          newPixelData: encodePixelData(pixelGrid)
        }
      })
      
      // Обновляем локальное состояние
      setChunk(selectedChunk, {
        ...chunks.get(selectedChunk)!,
        pixelData: pixelGrid
      })
      
      Alert.alert('✅ Успех', 'Пиксели обновлены!')
      toggleEditing(false)
    } catch (error: any) {
      Alert.alert('❌ Ошибка', error.message || 'Не удалось сохранить')
    }
  }
  
  if (!selectedChunk) return null
  
  return (
    <Modal visible={true} animationType="slide" onRequestClose={() => toggleEditing(false)}>
      <View className="flex-1 bg-canvas">
        {/* Заголовок */}
        <View className="flex-row justify-between items-center p-4 bg-chunk">
          <Text className="text-white text-lg">Редактирование чанка #{selectedChunk}</Text>
          <TouchableOpacity onPress={() => toggleEditing(false)}>
            <Text className="text-alephium">✕ Закрыть</Text>
          </TouchableOpacity>
        </View>
        
        {/* Сетка пикселей 16×16 */}
        <View className="flex-1 items-center justify-center">
          <View className="flex-row flex-wrap" style={{ width: 256, height: 256 }}>
            {Array.from({ length: 256 }).map((_, index) => {
              const byteIndex = Math.floor(index / 2)
              const isEven = index % 2 === 0
              const colorIndex = isEven 
                ? (pixelGrid[byteIndex] >> 4) & 0x0F
                : pixelGrid[byteIndex] & 0x0F
              
              return (
                <TouchableOpacity
                  key={index}
                  className="w-4 h-4 border border-gray-700"
                  style={{ backgroundColor: PALETTE[colorIndex] }}
                  onPress={() => handlePixelPress(index)}
                />
              )
            })}
          </View>
        </View>
        
        {/* Палитра цветов (16 цветов) */}
        <View className="flex-row justify-center p-4 bg-chunk">
          {PALETTE.map((color, index) => (
            <TouchableOpacity
              key={index}
              className={`w-8 h-8 m-1 rounded ${selectedColor === index ? 'border-2 border-alephium' : ''}`}
              style={{ backgroundColor: color }}
              onPress={() => setSelectedColor(index)}
            />
          ))}
        </View>
        
        {/* Кнопка сохранения */}
        <TouchableOpacity 
          className="m-4 py-3 bg-alephium rounded-lg"
          onPress={handleSave}
        >
          <Text className="text-center text-black font-bold">💾 Сохранить изменения</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  )
}
import { ChunkInfo } from '../contracts/AlepicContract';

// Локальный кэш состояний чанков (In-Memory Map для скорости)
// В продакшене нужно добавить сохранение в IndexedDB или AsyncStorage
class ChunkCache {
  private cache: Map<number, ChunkInfo> = new Map();

  update(chunkId: number, info: ChunkInfo) {
    this.cache.set(chunkId, info);
  }

  get(chunkId: number): ChunkInfo | undefined {
    return this.cache.get(chunkId);
  }

  getAll(): Map<number, ChunkInfo> {
    return this.cache;
  }
}

export const globalChunkCache = new ChunkCache();

/**
 * Класс для управления загрузкой и реконструкцией изображения
 */
export class ImageReconstructor {
  
  /**
   * Загрузить пакет чанков для видимой области
   * Оптимизация: загружаем только те, которых нет в кэше или которые устарели
   */
  async syncViewportChunks(chunkIds: number[]): Promise<void> {
    const missingIds = chunkIds.filter(id => !globalChunkCache.get(id));
    
    if (missingIds.length === 0) return;

    // В реальном приложении здесь будет batch-запрос к ноде
    // Для примера эмулируем параллельный запрос
    const promises = missingIds.map(id => 
      // contractService.getChunkInfo(id) - раскомментировать в проде
      Promise.resolve({ ownerId: null, colorIndex: 0, lastUpdatedBlock: 0n } as ChunkInfo)
        .then(info => globalChunkCache.update(id, info))
    );

    await Promise.all(promises);
  }

  /**
   * Получить массив цветов для рендеринга (Flat Array для Skia/Canvas)
   * Возвращает Uint8Array или подобную структуру для быстрой отрисовки
   */
  getRenderData(visibleChunkIds: number[]): Uint8Array {
    // 4-bit palette означает, что нам нужно мапить индексы 0-15 в реальные RGB цвета
    const PALETTE = [
      '#000000', '#FFFFFF', '#FF0000', '#00FF00', '#0000FF', 
      '#FFFF00', '#00FFFF', '#FF00FF', '#C0C0C0', '#808080', 
      '#800000', '#808000', '#008000', '#800080', '#008080', '#000080'
    ];

    const pixelBuffer = new Uint8Array(visibleChunkIds.length * 256 * 3); // RGB buffer
    
    let bufferIdx = 0;
    
    visibleChunkIds.forEach(chunkId => {
      const chunk = globalChunkCache.get(chunkId);
      const colorHex = chunk ? PALETTE[chunk.colorIndex] : PALETTE[0]; // Default black
      
      // Парсинг HEX в RGB для буфера
      const r = parseInt(colorHex.slice(1, 3), 16);
      const g = parseInt(colorHex.slice(3, 5), 16);
      const b = parseInt(colorHex.slice(5, 7), 16);

      // Заполняем 256 пикселей чанка одним цветом
      for (let i = 0; i < 256; i++) {
        pixelBuffer[bufferIdx++] = r;
        pixelBuffer[bufferIdx++] = g;
        pixelBuffer[bufferIdx++] = b;
      }
    });

    return pixelBuffer;
  }

  /**
   * Верификация целостности через Merkle Root (упрощенно)
   * Сравнивает локальный хэш состояния с закрепленным в блокчейне
   */
  async verifyIntegrity(expectedMerkleRoot: string): Promise<boolean> {
    // Вычисление хэша текущего состояния кэша
    // const localRoot = computeMerkleRoot(globalChunkCache.getAll());
    // return localRoot === expectedMerkleRoot;
    console.log("Integrity check simulated against root:", expectedMerkleRoot);
    return true;
  }
}

export const reconstructor = new ImageReconstructor();
require('dotenv').config();

module.exports = {
  expo: {
    name: 'Alepic',
    slug: 'alepic-canvas',
    version: '7.0.0', // Версия соответствует Whitepaper v7.0
    orientation: 'default',
    icon: './assets/images/icon.png',
    scheme: 'alepic',
    userInterfaceStyle: 'dark', // Принудительная темная тема
    
    splash: {
      image: './assets/images/splash.png',
      resizeMode: 'contain',
      backgroundColor: '#000000',
    },

    assetBundlePatterns: ['**/*'],

    // --- iOS Configuration ---
    ios: {
      supportsTablet: true,
      bundleIdentifier: 'org.alephium.alepic',
      buildNumber: '1',
      infoPlist: {
        NSCameraUsageDescription: 'Alepic needs camera access to scan QR codes for Billboard Mode activation (Section 8.1).',
        NSFaceIDUsageDescription: 'Secure your wallet transactions and chunk ownership with FaceID.',
        UIBackgroundModes: ['fetch', 'remote-notification'], // Для фоновой синхронизации событий Alepe
      },
      associatedDomains: ['applinks:alepic.io'],
    },

    // --- Android Configuration ---
    android: {
      adaptiveIcon: {
        foregroundImage: './assets/images/adaptive-icon.png',
        backgroundColor: '#000000',
      },
      package: 'org.alephium.alepic',
      versionCode: 1,
      permissions: [
        'CAMERA',
        'VIBRATE',
        'INTERNET',
        'ACCESS_NETWORK_STATE',
        'USE_BIOMETRIC',
        'POST_NOTIFICATIONS', // Критично для уведомлений о прыжках Alepe
      ],
    },

    // --- Web Configuration (PWA) ---
    web: {
      bundler: 'metro',
      output: 'static',
      favicon: './assets/images/favicon.png',
      description: 'Alephium Collaborative Canvas - A decentralized 4K public art experiment.',
      meta: {
        'theme-color': '#000000',
        'apple-mobile-web-app-capable': 'yes',
        'apple-mobile-web-app-status-bar-style': 'black-translucent',
        // ВАЖНО: Отключаем стандартный зум браузера, чтобы управлять зумом через Skia
        'viewport': 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no', 
      },
      configureWebpack: (config) => {
        // Полифилы для alephium-web3 (Node.js модули в браузере)
        config.resolve.fallback = {
          crypto: require.resolve('crypto-browserify'),
          stream: require.resolve('stream-browserify'),
          buffer: require.resolve('buffer'),
          process: require.resolve('process/browser'),
        };
        // Оптимизация для работы с большими массивами данных
        config.experiments = { ...config.experiments, asyncWebAssembly: true };
        return config;
      },
    },

    // --- Plugins ---
    plugins: [
      'expo-router',
      [
        'expo-notifications',
        {
          icon: './assets/images/notification-icon.png',
          color: '#00FF00', // Alephium Green
          sounds: ['./assets/sounds/alepe-jump.wav'], // Звук события Alepe
        },
      ],
      [
        'expo-camera',
        {
          cameraPermission: 'Allow Alepic to access your camera for QR scanning and Billboard linking.',
        },
      ],
      [
        'expo-build-properties',
        {
          ios: {
            useFrameworks: 'static',
          },
          android: {
            enableProguardInReleaseBuilds: true,
            // Сохраняем классы Skia при обфускации
            extraProguardRules: '-keep class com.swmansion.skia.** { *; }', 
          },
        },
      ],
      // Плагин для быстрой криптографии (необходим для подписи транзакций AluX)
      'react-native-quick-crypto',
    ],

    // --- Extra Config ---
    extra: {
      router: { origin: false },
      eas: { projectId: process.env.EAS_PROJECT_ID || '' },
      // Переменные окружения из .env
      apiUrl: process.env.EXPO_PUBLIC_API_NODE_URL || 'https://node.testnet.alephium.org',
      contractAddress: process.env.EXPO_PUBLIC_CONTRACT_ADDRESS || '',
      sentryDsn: process.env.EXPO_PUBLIC_SENTRY_DSN,
      isDevMode: process.env.EXPO_PUBLIC_ENABLE_DEV_MODE === 'true',
      whitepaperVersion: '7.0',
    },

    owner: 'alephium-community',
    runtimeVersion: { policy: 'appVersion' },
    
    updates: {
      url: 'https://u.expo.dev/' + (process.env.EAS_PROJECT_ID || ''),
      enabled: true,
      checkAutomatically: 'ON_LOAD',
      fallbackToCacheTimeout: 0,
    },
  },
};
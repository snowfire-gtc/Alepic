/**
 * Alepic 4-bit Indexed Color Palette
 * 
 * Согласно разделу 3.1 Whitepaper v7.0:
 * "Color Depth: Optimized 4-bit Indexed Palette to balance quality and on-chain storage costs."
 * 
 * Индексы 0-15 соответствуют цветам, хранящимся в смарт-контракте.
 * Формат: HEX строки для совместимости с React Native Skia и Web Canvas.
 */

export const PALETTE_SIZE = 16;

export interface ColorEntry {
  index: number;
  hex: string;
  rgb: { r: number; g: number; b: number };
  name?: string; // Опциональное имя для UI
}

// Определение стандартной палитры (можно настроить под брендбук Alepic)
// Используем классические яркие цвета для максимальной видимости на биллбордах.
export const PALETTE: ColorEntry[] = [
  { index: 0,  hex: '#000000', rgb: { r: 0,   g: 0,   b: 0   }, name: 'Black' },
  { index: 1,  hex: '#FFFFFF', rgb: { r: 255, g: 255, b: 255 }, name: 'White' },
  { index: 2,  hex: '#FF0000', rgb: { r: 255, g: 0,   b: 0   }, name: 'Red' },
  { index: 3,  hex: '#00FF00', rgb: { r: 0,   g: 255, b: 0   }, name: 'Alephium Green' }, // Бренд цвет
  { index: 4,  hex: '#0000FF', rgb: { r: 0,   g: 0,   b: 255 }, name: 'Blue' },
  { index: 5,  hex: '#FFFF00', rgb: { r: 255, g: 255, b: 0   }, name: 'Yellow' },
  { index: 6,  hex: '#00FFFF', rgb: { r: 0,   g: 255, b: 255 }, name: 'Cyan' },
  { index: 7,  hex: '#FF00FF', rgb: { r: 255, g: 0,   b: 255 }, name: 'Magenta' },
  { index: 8,  hex: '#C0C0C0', rgb: { r: 192, g: 192, b: 192 }, name: 'Silver' },
  { index: 9,  hex: '#808080', rgb: { r: 128, g: 128, b: 128 }, name: 'Gray' },
  { index: 10, hex: '#800000', rgb: { r: 128, g: 0,   b: 0   }, name: 'Maroon' },
  { index: 11, hex: '#808000', rgb: { r: 128, g: 128, b: 0   }, name: 'Olive' },
  { index: 12, hex: '#008000', rgb: { r: 0,   g: 128, b: 0   }, name: 'Green' },
  { index: 13, hex: '#800080', rgb: { r: 128, g: 0,   b: 128 }, name: 'Purple' },
  { index: 14, hex: '#008080', rgb: { r: 0,   g: 128, b: 128 }, name: 'Teal' },
  { index: 15, hex: '#000080', rgb: { r: 0,   g: 0,   b: 128 }, name: 'Navy' },
];

/**
 * Получить HEX цвет по индексу (0-15)
 * @param index Индекс цвета
 * @returns HEX строка или '#000000' если индекс неверен
 */
export const getColorByIndex = (index: number): string => {
  if (index < 0 || index >= PALETTE_SIZE) {
    console.warn(`Invalid color index: ${index}. Defaulting to Black.`);
    return PALETTE[0].hex;
  }
  return PALETTE[index].hex;
};

/**
 * Получить RGB объект по индексу
 * Полезно для низкоуровневой работы с буферами памяти (Uint8Array) в Skia/Canvas
 */
export const getRgbByIndex = (index: number): { r: number; g: number; b: number } => {
  if (index < 0 || index >= PALETTE_SIZE) {
    return PALETTE[0].rgb;
  }
  return PALETTE[index].rgb;
};

/**
 * Преобразовать HEX строку в ближайший индекс палитры (Euclidean distance)
 * Используется при импорте внешних изображений или выборе цвета в пипетке
 */
export const getClosestPaletteIndex = (hex: string): number => {
  // Парсинг входного HEX
  const cleanHex = hex.replace('#', '');
  const r = parseInt(cleanHex.substring(0, 2), 16);
  const g = parseInt(cleanHex.substring(2, 4), 16);
  const b = parseInt(cleanHex.substring(4, 6), 16);

  let minDistance = Infinity;
  let closestIndex = 0;

  for (const entry of PALETTE) {
    // Евклидово расстояние в пространстве RGB
    const dist = Math.sqrt(
      Math.pow(entry.rgb.r - r, 2) +
      Math.pow(entry.rgb.g - g, 2) +
      Math.pow(entry.rgb.b - b, 2)
    );

    if (dist < minDistance) {
      minDistance = dist;
      closestIndex = entry.index;
    }
  }

  return closestIndex;
};

/**
 * Генерация Uint8Array палитры для быстрой передачи в GPU/WebGL
 * Возвращает массив [R, G, B, R, G, B, ...] для всех 16 цветов
 */
export const getPaletteUint8Array = (): Uint8Array => {
  const buffer = new Uint8Array(PALETTE_SIZE * 3);
  PALETTE.forEach((entry, idx) => {
    buffer[idx * 3] = entry.rgb.r;
    buffer[idx * 3 + 1] = entry.rgb.g;
    buffer[idx * 3 + 2] = entry.rgb.b;
  });
  return buffer;
};
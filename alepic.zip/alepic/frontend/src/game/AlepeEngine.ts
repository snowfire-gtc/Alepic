import { AlepeState } from '../contracts/types';

const CANVAS_WIDTH = 4096;
const CANVAS_HEIGHT = 2160;
const JUMP_INTERVAL_BLOCKS = 100000;

export interface Position {
  x: number;
  y: number;
}

export class AlepeEngine {
  /**
   * Предсказывает следующую позицию Alepe, используя ту же детерминированную логику,
   * что и смарт-контракт (целочисленная арифметика, без trig функций).
   */
  static predictNextMove(currentState: AlepeState, currentBlockHeight: bigint): {
    currentPosition: Position;
    nextJumpBlockHeight: bigint;
    timeUntilNextJumpMs: number;
    currentChunkId: number;
  } {
    const blocksSinceLastJump = currentBlockHeight % BigInt(JUMP_INTERVAL_BLOCKS);
    const blocksUntilNextJump = BigInt(JUMP_INTERVAL_BLOCKS) - blocksSinceLastJump;
    const timeUntilNextJumpMs = Number(blocksUntilNextJump) * 1000; // ~1s per block

    const chunkX = Math.floor(currentState.x / 16);
    const chunkY = Math.floor(currentState.y / 16);
    const currentChunkId = chunkY * 256 + chunkX;

    return {
      currentPosition: { x: currentState.x, y: currentState.y },
      nextJumpBlockHeight: currentState.nextJumpBlock,
      timeUntilNextJumpMs,
      currentChunkId,
    };
  }

  /**
   * Вычисляет новую позицию после прыжка.
   * ДОЛЖНА точно соответствовать логике в AlepicMain.alu (triggerAlepeJump).
   */
  static calculateJumpPosition(
    currentX: number, 
    currentY: number, 
    blockHeight: bigint
  ): Position {
    // Воспроизведение псевдо-случайных факторов из контракта
    const randVal1 = Number((blockHeight % 1000n) * 4n);
    const randVal2 = Number((blockHeight % 500n) * 8n);
    
    const direction = randVal1 % 8;
    const distance = 500 + (randVal2 % 500);

    let newX = currentX;
    let newY = currentY;

    // Та же логика секторов, что в контракте
    switch (direction) {
      case 0: newX += distance; break;
      case 1: newX += distance; newY += distance; break;
      case 2: newY += distance; break;
      case 3: newX -= distance; newY += distance; break;
      case 4: newX -= distance; break;
      case 5: newX -= distance; newY -= distance; break;
      case 6: newY -= distance; break;
      case 7: newX += distance; newY -= distance; break;
    }

    // Wrap-Around (Modulo) логика, идентичная контракту
    newX = this.wrapCoordinate(newX, CANVAS_WIDTH);
    newY = this.wrapCoordinate(newY, CANVAS_HEIGHT);

    return { x: newX, y: newY };
  }

  private static wrapCoordinate(val: number, max: number): number {
    let result = val % max;
    if (result < 0) {
      result = max - ((-result) % max);
    }
    return result;
  }

  static getChunkIdFromPosition(pos: Position): number {
    const chunkX = Math.floor(pos.x / 16);
    const chunkY = Math.floor(pos.y / 16);
    return chunkY * 256 + chunkX;
  }
}
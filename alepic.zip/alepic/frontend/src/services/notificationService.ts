import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { logger } from '../utils/logger';
import { formatAlph } from '../utils/formatters';

// Настройка поведения уведомлений в приложении
Notifications.setNotificationHandler({
  handleNotificationReceived: async (notification) => {
    logger.info('NotificationService', 'Notification received', notification.request.content);
  },
  handleNotificationClicked: async (notification) => {
    logger.info('NotificationService', 'Notification clicked', notification.request.content);
    // Здесь можно добавить навигацию на конкретный чанк или экран-dashboard
  },
});

class NotificationService {
  private isInitialized = false;

  /**
   * Инициализация сервиса (запрос прав, настройка каналов)
   * Должен вызываться при старте приложения
   */
  async initialize(): Promise<boolean> {
    if (this.isInitialized) return true;

    if (!Device.isDevice) {
      logger.warn('NotificationService', 'Push notifications not available on simulator');
      return false;
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      logger.warn('NotificationService', 'Permission not granted');
      return false;
    }

    // Создание канала для важных событий игры Alepe
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('alepe-game', {
        name: 'Alepe Game Events',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#FF0000',
      });
      
      await Notifications.setNotificationChannelAsync('transactions', {
        name: 'Transactions',
        importance: Notifications.AndroidImportance.DEFAULT,
      });
    }

    this.isInitialized = true;
    return true;
  }

  /**
   * Уведомление о прыжке Alepe и возможной награде
   * @param chunkId ID чанка, куда прыгнула Alepe
   * @param hasReward Есть ли награда
   * @param rewardAmount Сумма награды (если есть)
   */
  async notifyAlepeJump(chunkId: number, hasReward: boolean, rewardAmount?: bigint) {
    if (!this.isInitialized) return;

    const title = hasReward ? '🎉 Alepe Landed on Your Chunk!' : '🦊 Alepe Has Jumped';
    const body = hasReward 
      ? `Alepe landed on your chunk #${chunkId}. You received ${formatAlph(rewardAmount!)} from the Treasury!`
      : `Alepe jumped to chunk #${chunkId}. No owner found, funds remain in Treasury.`;

    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data: { chunkId, type: 'alepe_jump' },
        sound: 'default',
      },
      trigger: null, // Немедленно
      identifier: 'alepe-game', // Для Android channel
    });
  }

  /**
   * Уведомление об успешной транзакции
   */
  async notifyTransactionSuccess(type: 'buy' | 'sell' | 'update', chunkId: number) {
    if (!this.isInitialized) return;

    const titles = {
      buy: 'Chunk Acquired!',
      sell: 'Chunk Sold!',
      update: 'Art Updated!',
    };

    await Notifications.scheduleNotificationAsync({
      content: {
        title: titles[type],
        body: `Your transaction for chunk #${chunkId} was confirmed on Alephium.`,
        data: { chunkId, type: 'tx_success' },
      },
      trigger: null,
      identifier: 'transactions',
    });
  }

  /**
   * Локальное всплывающее уведомление (Toast) внутри UI
   * (Реализация зависит от UI библиотеки, здесь логика триггера)
   */
  showToast(message: string, type: 'success' | 'error' | 'info') {
    // Интегрируется с компонентом Toast в UI слое
    logger.info('NotificationService', `Toast: [${type}] ${message}`);
  }
}

export const notificationService = new NotificationService();
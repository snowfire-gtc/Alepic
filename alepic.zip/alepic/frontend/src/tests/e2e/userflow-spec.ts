/**
 * Detox или Maestro
 * E2E Test Scenario: User buys a chunk and edits it
 * Precondition: App is installed, Wallet is funded with testnet ALPH
 */

describe('Full User Flow: Claim & Edit', () => {
  
  it('should allow user to connect, buy a chunk, change color, and see Alepe', async () => {
    // 1. Launch App
    await device.launchApp();
    
    // 2. Connect Wallet
    await element(by.text('Connect Wallet')).tap();
    await waitFor(element(by.text('0x...'))).toBeVisible().withTimeout(5000);
    
    // 3. Navigate to an unclaimed chunk (Center of screen)
    // Эмуляция зума и клика по центру
    await element(by.id('canvas-view')).pinchWithSpeed(0.5, 'out', 0.5); 
    await element(by.id('chunk-center')).tap();
    
    // 4. Verify Purchase Modal appears
    await expect(element(by.text('Confirm Purchase'))).toBeVisible();
    await expect(element(by.text('Price: 1 ALPH'))).toBeVisible(); // Первый чанк
    
    // 5. Confirm Transaction
    await element(by.text('Confirm Buy')).tap();
    
    // 6. Wait for Transaction Success Toast
    await waitFor(element(by.text('Chunk Acquired!'))).toBeVisible().withTimeout(15000);
    
    // 7. Edit Chunk Color
    await element(by.id('chunk-center')).longPress(); // Long press to edit
    await element(by.id('color-red')).tap(); // Select Red
    await element(by.text('Update')).tap();
    
    // 8. Verify Visual Update
    // Проверяем, что цвет чанка изменился на красный (через snapshot или анализ пикселей)
    await expect(element(by.id('chunk-center'))).toHaveStyle({ backgroundColor: '#FF0000' });
    
    // 9. Check Alepe Overlay
    // Если сейчас время прыжка, проверяем наличие талисмана
    // (В тесте можно замокать время)
    await expect(element(by.id('alepe-mascot'))).toExist(); 
  });
});
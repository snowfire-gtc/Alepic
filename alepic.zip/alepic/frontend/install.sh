npm install expo-build-properties expo-camera expo-notifications react-native-quick-crypto crypto-browserify stream-browserify buffer

npx expo install expo-keep-awake
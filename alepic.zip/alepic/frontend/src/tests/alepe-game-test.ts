import { AlepeEngine } from '../game/AlepeEngine';
import { RewardChecker } from '../game/rewardChecker';
import { ChunkInfo } from '../contracts/types';

describe('Alepe Game Logic (Whitepaper Sec 4 & 6.3)', () => {
  
  describe('Jump Prediction', () => {
    const mockState = {
      x: 2048,
      y: 1080,
      nextJumpBlock: 100000n,
      treasuryBalance: BigInt(1000 * 1e18),
      sessionStartBlock: 0n
    };

    it('should calculate time until next jump correctly', () => {
      const currentBlock = 50000n; // Halfway to jump
      const prediction = AlepeEngine.predictNextMove(mockState, currentBlock);
      
      // Interval is 100,000 blocks. 50k passed, 50k remaining.
      // ~1 block/sec => 50,000 seconds
      expect(prediction.timeUntilNextJumpMs).toBeCloseTo(50000 * 1000, -2);
    });

    it('should handle wrap-around logic for coordinates', () => {
      // Эмуляция выхода за границы
      const wrappedX = AlepeEngine.wrapCoordinate(5000, 4096); // 5000 > 4096
      expect(wrappedX).toBe(5000 % 4096);
      
      const wrappedNegX = AlepeEngine.wrapCoordinate(-100, 4096);
      expect(wrappedNegX).toBe(4096 - 100);
    });
  });

  describe('Reward Distribution', () => {
    it('should award 1% of Treasury if Alepe lands on owned chunk', () => {
      const ownedChunk: ChunkInfo = { ownerId: '0xOwner...', colorIndex: 5, lastUpdatedBlock: 100n };
      const treasuryBalance = BigInt(10000 * 1e18); // 10,000 ALPH
      
      const result = RewardChecker.processJumpResult(
        ownedChunk, 
        treasuryBalance, 
        { x: 100, y: 100 }, 
        { x: 0, y: 0 }, 
        100000n
      );

      expect(result.rewardIssued).toBe(true);
      expect(result.winnerAddress).toBe('0xOwner...');
      // 1% of 10,000 = 100 ALPH
      expect(result.rewardAmount).toBe(BigInt(100 * 1e18));
    });

    it('should NOT award reward if Alepe lands on unclaimed chunk', () => {
      const unclaimedChunk: ChunkInfo = { ownerId: null, colorIndex: 0, lastUpdatedBlock: 0n };
      const treasuryBalance = BigInt(10000 * 1e18);
      
      const result = RewardChecker.processJumpResult(
        unclaimedChunk, 
        treasuryBalance, 
        { x: 100, y: 100 }, 
        { x: 0, y: 0 }, 
        100000n
      );

      expect(result.rewardIssued).toBe(false);
      expect(result.winnerAddress).toBeUndefined();
      expect(result.rewardAmount).toBeUndefined();
      // Funds remain in Treasury (логика проверяется косвенно отсутствием выплаты)
    });
  });
});
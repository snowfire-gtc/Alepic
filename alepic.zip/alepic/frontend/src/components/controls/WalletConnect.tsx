import React from 'react';
import { TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import { useWallet } from '../../hooks/useWallet';
import { shortenAddress } from '../../utils/formatters';

export const WalletConnect: React.FC = () => {
  const { isConnected, address, balance, connect, disconnect, loading } = useWallet();

  if (isConnected && address) {
    return (
      <View style={styles.connectedContainer}>
        <TouchableOpacity style={styles.walletButton} onPress={disconnect}>
          <Text style={styles.addressText}>{shortenAddress(address)}</Text>
          <Text style={styles.balanceText}>{/* Форматирование баланса */} {Number(balance) / 1e18} ALPH</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <TouchableOpacity 
      style={[styles.connectButton, loading && styles.disabledButton]} 
      onPress={connect}
      disabled={loading}
    >
      <Text style={styles.connectText}>
        {loading ? 'Connecting...' : 'Connect Wallet'}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  connectedContainer: {
    position: 'absolute',
    top: 20,
    right: 20,
  },
  walletButton: {
    backgroundColor: 'rgba(0, 255, 0, 0.2)',
    borderWidth: 1,
    borderColor: '#00FF00',
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  addressText: {
    color: '#00FF00',
    fontWeight: 'bold',
    fontSize: 14,
  },
  balanceText: {
    color: '#FFFFFF',
    fontSize: 12,
    marginTop: 2,
  },
  connectButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  disabledButton: {
    opacity: 0.6,
  },
  connectText: {
    color: '#000000',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
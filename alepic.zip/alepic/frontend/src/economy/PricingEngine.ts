import { BigIntUtils } from 'alephium-web3';

const BASE_PRICE_ALPH = 1n;
const PRICE_INCREMENT = 1n;
const TOTAL_CHUNKS = 34560;

// Константы комиссий (из раздела 6.2)
const SECONDARY_SALE_FEE_PERCENT = 5; // 5%
const REFERRER_SHARE_OF_FEE = 20; // 20% от комиссии (итого 1% от суммы сделки)
const TREASURY_SHARE_OF_FEE = 80; // 80% от комиссии (итого 4% от суммы сделки)

export interface PricingResult {
  price: bigint;
  isInitialClaim: boolean;
  estimatedFee?: bigint;
  referrerReward?: bigint;
}

export class PricingEngine {
  /**
   * Рассчитать цену для конкретного чанка на основе количества уже занятых чанков.
   * Формула: Price = 1 + (CountOfClaimedChunks)
   */
  static calculateClaimPrice(claimedCount: number): bigint {
    if (claimedCount >= TOTAL_CHUNKS) {
      throw new Error("All chunks are claimed. Only secondary market available.");
    }
    return BASE_PRICE_ALPH + BigInt(claimedCount) * PRICE_INCREMENT;
  }

  /**
   * Рассчитать распределение средств при вторичной продаже
   * @param salePrice Цена продажи
   * @param hasReferrer Есть ли адрес реферера в транзакции
   */
  static calculateSecondaryDistribution(salePrice: bigint, hasReferrer: boolean) {
    const totalFee = (salePrice * BigInt(SECONDARY_SALE_FEE_PERCENT)) / 100n;
    
    let referrerReward = 0n;
    let treasuryShare = totalFee;

    if (hasReferrer) {
      // 20% от комиссии идет рефереру
      referrerReward = (totalFee * BigInt(REFERRER_SHARE_OF_FEE)) / 100n;
      treasuryShare = totalFee - referrerReward;
    }

    const sellerReceives = salePrice - totalFee;

    return {
      sellerReceives,
      treasuryShare,
      referrerReward,
      totalFee
    };
  }

  /**
   * Получить максимальную теоретическую цену последнего чанка
   */
  static getMaxTheoreticalPrice(): bigint {
    return BASE_PRICE_ALPH + BigInt(TOTAL_CHUNKS - 1) * PRICE_INCREMENT;
  }
}
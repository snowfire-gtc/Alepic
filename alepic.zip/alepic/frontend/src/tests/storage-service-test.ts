import { storageService } from '../services/storageService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ChunkInfo } from '../contracts/types';

jest.mock('@react-native-async-storage/async-storage');

describe('Storage Service (Whitepaper Sec 3.3)', () => {
  const mockChunk1: ChunkInfo = { ownerId: '0x1', colorIndex: 1, lastUpdatedBlock: 100n };
  const mockChunk2: ChunkInfo = { ownerId: '0x2', colorIndex: 2, lastUpdatedBlock: 101n };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('saveChunks & getChunks', () => {
    it('should save and retrieve chunks correctly', async () => {
      await storageService.saveChunks({ 1: mockChunk1, 2: mockChunk2 });
      
      expect(AsyncStorage.setItem).toHaveBeenCalledWith(
        'alepic_chunk_cache_v1',
        expect.any(String)
      );

      // Эмулируем чтение
      const savedData = JSON.stringify({ 1: mockChunk1, 2: mockChunk2 });
      (AsyncStorage.getItem as jest.Mock).mockResolvedValue(savedData);

      const result = await storageService.getChunks();
      expect(result[1]).toEqual(mockChunk1);
      expect(result[2]).toEqual(mockChunk2);
    });

    it('should return empty object if no data exists', async () => {
      (AsyncStorage.getItem as jest.Mock).mockResolvedValue(null);
      const result = await storageService.getChunks();
      expect(result).toEqual({});
    });

    it('should enforce MAX_CACHED_CHUNKS limit (LRU simulation)', async () => {
      // Создаем массив из 5005 чанков (лимит 5000)
      const largeDataset: Record<number, ChunkInfo> = {};
      for (let i = 0; i < 5005; i++) {
        largeDataset[i] = { ownerId: `0x${i}`, colorIndex: 0, lastUpdatedBlock: BigInt(i) };
      }

      await storageService.saveChunks(largeDataset);

      // Проверяем, что setItem был вызван (логика обрезки внутри функции)
      expect(AsyncStorage.setItem).toHaveBeenCalled();
      
      // В реальной реализации мы бы проверили размер переданной строки JSON,
      // но здесь проверяем вызов метода
      const callArg = (AsyncStorage.setItem as jest.Mock).mock.calls[0][1];
      const parsed = JSON.parse(callArg);
      expect(Object.keys(parsed).length).toBeLessThanOrEqual(5000);
    });
  });

  describe('Settings Management', () => {
    it('should merge new settings with defaults', async () => {
      (AsyncStorage.getItem as jest.Mock).mockResolvedValue(null);
      
      await storageService.saveSettings({ network: 'mainnet' });
      
      const expected = {
        network: 'mainnet',
        showAlepeOverlay: true, // default
        language: 'en',         // default
        lastSyncBlock: '0',     // default (serialized)
      };
      
      expect(AsyncStorage.setItem).toHaveBeenCalledWith(
        'alepic_settings_v1',
        JSON.stringify(expected)
      );
    });
  });
});
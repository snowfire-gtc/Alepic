type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  module: string;
  message: string;
  data?: any;
}

class Logger {
  private minLevel: LogLevel = 'info'; // По умолчанию скрываем debug в продакшене
  private isDev: boolean = __DEV__; // Expo/RN глобальная переменная

  constructor(minLevel: LogLevel = 'info') {
    this.minLevel = minLevel;
  }

  private getLevelPriority(level: LogLevel): number {
    const priorities: Record<LogLevel, number> = {
      debug: 0,
      info: 1,
      warn: 2,
      error: 3,
    };
    return priorities[level];
  }

  private log(level: LogLevel, module: string, message: string, data?: any) {
    if (this.getLevelPriority(level) < this.getLevelPriority(this.minLevel) && !this.isDev) {
      return;
    }

    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      module,
      message,
      data,
    };

    const prefix = `[${entry.timestamp}] [${level.toUpperCase()}] [${module}]`;
    
    switch (level) {
      case 'debug':
        if (this.isDev) console.debug(prefix, message, data || '');
        break;
      case 'info':
        console.info(prefix, message, data || '');
        break;
      case 'warn':
        console.warn(prefix, message, data || '');
        break;
      case 'error':
        console.error(prefix, message, data || '');
        // Здесь можно добавить отправку ошибок в сервис мониторинга (Sentry и т.д.)
        break;
    }
  }

  debug(module: string, message: string, data?: any) {
    this.log('debug', module, message, data);
  }

  info(module: string, message: string, data?: any) {
    this.log('info', module, message, data);
  }

  warn(module: string, message: string, data?: any) {
    this.log('warn', module, message, data);
  }

  error(module: string, message: string, error?: any) {
    this.log('error', module, message, error);
  }
}

// Экспорт единственного экземпляра
export const logger = new Logger(__DEV__ ? 'debug' : 'warn');

// Пример использования:
// logger.info('Network', 'Switched to testnet', { url: '...' });
// logger.error('Contract', 'Transaction failed', err);
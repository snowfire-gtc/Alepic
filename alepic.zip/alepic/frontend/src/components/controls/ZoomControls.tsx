import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Или любой другой набор иконок

interface ZoomControlsProps {
  onZoomIn: () => void;
  onZoomOut: () => void;
  onReset: () => void;
  currentZoom: number;
}

export const ZoomControls: React.FC<ZoomControlsProps> = ({
  onZoomIn,
  onZoomOut,
  onReset,
  currentZoom,
}) => {
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.button} onPress={onZoomOut} activeOpacity={0.7}>
        <Ionicons name="remove" size={24} color="#FFFFFF" />
      </TouchableOpacity>
      
      <View style={styles.zoomIndicator}>
        {/* Простой индикатор масштаба */}
        <Text style={styles.zoomText}>{Math.round(currentZoom * 100)}%</Text>
      </View>

      <TouchableOpacity style={styles.button} onPress={onZoomIn} activeOpacity={0.7}>
        <Ionicons name="add" size={24} color="#FFFFFF" />
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, styles.resetButton]} onPress={onReset} activeOpacity={0.7}>
        <Ionicons name="expand" size={20} color="#FFFFFF" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    right: 20,
    bottom: 40,
    flexDirection: 'column',
    alignItems: 'center',
    gap: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    padding: 10,
    borderRadius: 30,
    backdropFilter: 'blur(10px)', // Эффект стекла для Web
  },
  button: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  resetButton: {
    marginTop: 5,
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  zoomIndicator: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 12,
  },
  zoomText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
});
// Кодирование массива 256 значений (0-15) в 128 байт (4-bit палитра)
export const encodePixelData = (pixels: Uint8Array): Uint8Array => {
  if (pixels.length !== 256) throw new Error('Expected 256 pixels')
  
  const result = new Uint8Array(128)
  for (let i = 0; i < 256; i += 2) {
    const high = pixels[i] & 0x0F
    const low = pixels[i + 1] & 0x0F
    result[i / 2] = (high << 4) | low
  }
  return result
}

// Декодирование 128 байт в массив из 256 значений (0-15)
export const decodePixelData = (byteVec: Uint8Array): Uint8Array => {
  if (byteVec.length !== 128) throw new Error('Expected 128 bytes')
  
  const result = new Uint8Array(256)
  for (let i = 0; i < 128; i++) {
    result[i * 2] = (byteVec[i] >> 4) & 0x0F
    result[i * 2 + 1] = byteVec[i] & 0x0F
  }
  return result
}
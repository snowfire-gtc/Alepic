import React, { memo, useCallback, useMemo } from 'react'
import { View, ScrollView, Dimensions } from 'react-native'
import { Gesture, GestureDetector } from 'react-native-gesture-handler'
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated'
import { useCanvasStore } from '../../store/useCanvasStore'
import { ChunkTile } from './ChunkTile'
import { AlepeMarker } from './AlepeMarker'
import { chunkIdToCoords, coordsToChunkId } from '../../utils/chunkMath'
import { useAlepeGame } from '../../hooks/useAlepeGame'

const CANVAS_WIDTH = 4096
const CANVAS_HEIGHT = 2160
const CHUNK_SIZE = 16

export const CanvasView = memo(() => {
  const { viewport, setViewport, alepe, getVisibleChunks, chunks } = useCanvasStore()
  const { x, y, zoom } = viewport
  const visibleChunks = getVisibleChunks()
  
  // Анимация зума и панорамирования
  const offsetX = useSharedValue(x)
  const offsetY = useSharedValue(y)
  const scale = useSharedValue(zoom)
  
  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: offsetX.value },
      { translateY: offsetY.value },
      { scale: scale.value }
    ]
  }))
  
  // Жесты для панорамирования и зума
  const panGesture = Gesture.Pan()
    .onUpdate((e) => {
      offsetX.value = x + e.translationX
      offsetY.value = y + e.translationY
    })
    .onEnd((e) => {
      setViewport({ 
        x: x + e.translationX, 
        y: y + e.translationY, 
        zoom 
      })
    })
  
  const pinchGesture = Gesture.Pinch()
    .onUpdate((e) => {
      scale.value = Math.max(0.5, Math.min(4, zoom * e.scale))
    })
    .onEnd((e) => {
      const newZoom = Math.max(0.5, Math.min(4, zoom * e.scale))
      setViewport({ x, y, zoom: newZoom })
    })
  
  const compositeGesture = Gesture.Simultaneous(panGesture, pinchGesture)
  
  // Подписка на обновления Alepe
  useAlepeGame()
  
  return (
    <GestureDetector gesture={compositeGesture}>
      <Animated.View style={[{ flex: 1, backgroundColor: '#0a0a1a' }, animatedStyle]}>
        {/* Контейнер канваса фиксированного размера */}
        <View style={{ width: CANVAS_WIDTH, height: CANVAS_HEIGHT }}>
          {/* Рендеринг только видимых чанков для оптимизации */}
          {visibleChunks.map((chunkId) => (
            <ChunkTile 
              key={chunkId}
              chunkId={chunkId}
              data={chunks.get(chunkId)}
              onPress={() => useCanvasStore.getState().selectChunk(chunkId)}
            />
          ))}
          
          {/* Маркер маскота Alepe */}
          <AlepeMarker x={alepe.x} y={alepe.y} />
        </View>
      </Animated.View>
    </GestureDetector>
  )
})
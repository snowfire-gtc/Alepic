import { useState, useCallback } from 'react';
import { batchSender } from '../services/batchSender';
import { pixelToChunkId } from '../utils/math';

export const usePixelDrawer = (isEnabled: boolean) => {
  const [isDrawing, setIsDrawing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  // Обработка начала рисования (нажатие)
  const handleStart = useCallback((x: number, y: number, colorIndex: number) => {
    if (!isEnabled) return;
    setIsDrawing(true);
    handleMove(x, y, colorIndex);
  }, [isEnabled]);

  // Обработка движения (рисование)
  const handleMove = useCallback((x: number, y: number, colorIndex: number) => {
    if (!isDrawing || !isEnabled) return;

    const chunkId = pixelToChunkId(x, y);
    if (chunkId === -1) return;

    // Вычисление локального индекса пикселя (0..255)
    const localX = x % 16;
    const localY = y % 16;
    const pixelIndex = localY * 16 + localX;

    // Добавляем в буфер
    batchSender.addChange(chunkId, pixelIndex, colorIndex);
    
    // Обновляем счетчик для UI
    setPendingCount(batchSender.getCount());
  }, [isDrawing, isEnabled]);

  // Обработка конца рисования
  const handleEnd = useCallback(() => {
    setIsDrawing(false);
  }, []);

  // Отправка накопленных изменений
  const submitChanges = useCallback(async () => {
    const success = await batchSender.submitChanges();
    if (success) {
      setPendingCount(0);
    }
    return success;
  }, []);

  return {
    isDrawing,
    pendingCount,
    handlers: {
      onStart: handleStart,
      onMove: handleMove,
      onEnd: handleEnd,
    },
    submitChanges,
  };
};
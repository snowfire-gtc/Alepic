import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DEFAULT_ADMIN_PIN } from '../../config/billboardConfig';

interface PinPadModalProps {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
  title: string;
}

export const PinPadModal: React.FC<PinPadModalProps> = ({ visible, onClose, onSuccess, title }) => {
  const [pin, setPin] = useState('');

  const handleNumberPress = (num: string) => {
    if (pin.length < 4) {
      setPin((prev) => prev + num);
    }
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
  };

  const handleSubmit = () => {
    if (pin === DEFAULT_ADMIN_PIN) {
      setPin('');
      onSuccess();
    } else {
      // Вибрация при ошибке (опционально)
      alert('Incorrect PIN'); 
      setPin('');
    }
  };

  return (
    <Modal transparent visible={visible} animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.container}>
          <Text style={styles.title}>{title}</Text>
          
          {/* Индикаторы введенных цифр */}
          <View style={styles.pinDisplay}>
            {[0, 1, 2, 3].map((i) => (
              <View 
                key={i} 
                style={[styles.dot, i < pin.length && styles.dotFilled]} 
              />
            ))}
          </View>

          {/* Клавиатура */}
          <View style={styles.keypad}>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <TouchableOpacity key={num} style={styles.key} onPress={() => handleNumberPress(num.toString())}>
                <Text style={styles.keyText}>{num}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.key} onPress={() => {}}><Text style={styles.keyText}></Text></TouchableOpacity>
            <TouchableOpacity style={styles.key} onPress={() => handleNumberPress('0')}>
              <Text style={styles.keyText}>0</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.key} onPress={handleBackspace}>
              <Ionicons name="backspace-outline" size={24} color="#FFF" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
            <Text style={styles.submitText}>Enter</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Text style={styles.closeText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.9)', justifyContent: 'center', alignItems: 'center' },
  container: { width: 300, backgroundColor: '#222', padding: 24, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: '#333' },
  title: { color: '#FFF', fontSize: 18, marginBottom: 24, fontWeight: 'bold', textAlign: 'center' },
  pinDisplay: { flexDirection: 'row', gap: 16, marginBottom: 32 },
  dot: { width: 14, height: 14, borderRadius: 7, borderWidth: 2, borderColor: '#555' },
  dotFilled: { backgroundColor: '#00FF00', borderColor: '#00FF00' },
  keypad: { flexDirection: 'row', flexWrap: 'wrap', width: 240, justifyContent: 'space-between', marginBottom: 20 },
  key: { width: 64, height: 64, justifyContent: 'center', alignItems: 'center', marginBottom: 12, borderRadius: 12, backgroundColor: '#333' },
  keyText: { color: '#FFF', fontSize: 24, fontWeight: '600' },
  submitButton: { backgroundColor: '#00FF00', paddingHorizontal: 48, paddingVertical: 14, borderRadius: 8, marginTop: 10, width: '100%', alignItems: 'center' },
  submitText: { color: '#000', fontWeight: 'bold', fontSize: 16 },
  closeButton: { marginTop: 20, padding: 10 },
  closeText: { color: '#666', fontSize: 14 },
});
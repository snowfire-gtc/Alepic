import { pixelToChunkId, chunkIdToPixel, wrapCoordinate } from '../math';
import { getColorByIndex, getClosestPaletteIndex, PALETTE_SIZE } from '../../data/palette';

describe('Canvas Math & Grid Logic (Sec 3.2)', () => {
  const CANVAS_WIDTH = 4096;
  const CANVAS_HEIGHT = 2160;
  const CHUNK_SIZE = 16;

  it('should convert center pixel to correct chunk ID', () => {
    // Центр холста (2048, 1080)
    const chunkId = pixelToChunkId(2048, 1080);
    // Ожидаем: x=128, y=67 -> ID = 67 * 256 + 128 = 17280
    expect(chunkId).toBe(17280);
  });

  it('should handle edge cases for chunk conversion', () => {
    // Последний пиксель右下 угла
    const lastChunkId = pixelToChunkId(4095, 2159);
    expect(lastChunkId).toBe(34559); // Всего 34560 чанков (0..34559)

    // Отрицательные координаты должны возвращать -1
    expect(pixelToChunkId(-1, 0)).toBe(-1);
    expect(pixelToChunkId(0, -1)).toBe(-1);
  });

  it('should reverse convert chunk ID to pixel coordinates', () => {
    const pos = chunkIdToPixel(0);
    expect(pos).toEqual({ x: 0, y: 0 });

    const posCenter = chunkIdToPixel(17280);
    expect(posCenter).toEqual({ x: 2048, y: 1072 }); // 1072 = 67 * 16 (верхний левый угол чанка)
  });

  describe('Wrap-Around Logic (Sec 4)', () => {
    it('should wrap coordinates exceeding canvas width', () => {
      const wrapped = wrapCoordinate(4100, 4096);
      expect(wrapped).toBe(4); // 4100 % 4096
    });

    it('should wrap negative coordinates correctly', () => {
      const wrapped = wrapCoordinate(-10, 4096);
      expect(wrapped).toBe(4086); // 4096 - 10
    });
  });
});

describe('4-bit Palette Logic (Sec 3.1)', () => {
  it('should return valid hex for all 16 indices', () => {
    for (let i = 0; i < PALETTE_SIZE; i++) {
      const color = getColorByIndex(i);
      expect(color).toMatch(/^#[0-9A-F]{6}$/i);
    }
  });

  it('should default to black for invalid indices', () => {
    expect(getColorByIndex(-1)).toBe('#000000');
    expect(getColorByIndex(100)).toBe('#000000');
  });

  it('should find closest palette color for input hex', () => {
    // Чистый красный должен совпасть с красным в палитре (индекс 2)
    const index = getClosestPaletteIndex('#FF0000');
    expect(index).toBe(2);

    // Чистый белый -> индекс 1
    expect(getClosestPaletteIndex('#FFFFFF')).toBe(1);
    
    // Черный -> индекс 0
    expect(getClosestPaletteIndex('#000000')).toBe(0);
  });
});
import { PixelChange } from '../contracts/types';
import { contractService } from '../contracts/AlepicContract';
import { Alert } from 'react-native';
import { logger } from '../utils/logger';

interface PendingChange extends PixelChange {
  timestamp: number;
}

class BatchSenderService {
  private pendingChanges: Map<string, PendingChange> = new Map();
  // Начинаем с максимума, определенного в контракте
  private currentMaxBatchSize = 200; 

  addChange(chunkId: number, pixelIndex: number, colorIndex: number) {
    const key = `${chunkId}-${pixelIndex}`;
    this.pendingChanges.set(key, {
      chunkId,
      pixelIndex,
      colorIndex,
      timestamp: Date.now(),
    });
  }

  getCount(): number {
    return this.pendingChanges.size;
  }

  clear() {
    this.pendingChanges.clear();
  }

  async submitChanges(): Promise<boolean> {
    if (this.pendingChanges.size === 0) return false;

    const changesArray = Array.from(this.pendingChanges.values());
    const uniqueChunks = new Set(changesArray.map(c => c.chunkId));
    
    const totalEstimatedCostALPH = (changesArray.length * 0.00005) + 0.0001;
    
    const confirmed = await new Promise<boolean>((resolve) => {
      Alert.alert(
        "Confirm Batch Update",
        `Update ${changesArray.length} pixels in ${uniqueChunks.size} chunks.\n\nEstimated Cost: ~${totalEstimatedCostALPH.toFixed(6)} ALPH`,
        [
          { text: "Cancel", style: "cancel", onPress: () => resolve(false) },
          { text: "Sign & Send", onPress: () => resolve(true) }
        ]
      );
    });

    if (!confirmed) return false;

    try {
      const referrer = process.env.EXPO_PUBLIC_DEVELOPER_ADDRESS;
      
      // АДАПТИВНАЯ РАЗБИВКА
      // Если транзакция падает, уменьшаем размер пакета и пробуем снова
      let batchSize = this.currentMaxBatchSize;
      let processedCount = 0;

      while (processedCount < changesArray.length) {
        const batch = changesArray.slice(processedCount, processedCount + batchSize);
        
        try {
          await contractService.batchUpdatePixels(batch, referrer);
          processedCount += batch.length;
          // Если успешно, можно попробовать увеличить размер для следующего батча (опционально)
          if (batchSize < 200) batchSize = Math.min(200, batchSize + 50); 
        } catch (error: any) {
          // ЛОВЛЯ ОШИБОК ГАЗА / РАЗМЕРА
          if (error.message?.includes('Gas') || error.message?.includes('large') || error.message?.includes('limit')) {
            logger.warn('BatchSender', `Batch size ${batchSize} failed. Reducing...`);
            batchSize = Math.floor(batchSize / 2);
            
            if (batchSize < 10) {
              throw new Error("Transaction failed even with minimal batch size. Network issue?");
            }
            // Повторяем ту же итерацию с меньшим размером (не увеличиваем processedCount)
            continue; 
          } else {
            throw error; // Другая ошибка, пробрасываем дальше
          }
        }
      }

      this.clear();
      logger.info('BatchSender', 'All batches submitted successfully');
      return true;
    } catch (error) {
      logger.error('BatchSender', 'Submission failed', error);
      Alert.alert("Error", "Transaction failed. Changes were not saved.");
      return false;
    }
  }
}

export const batchSender = new BatchSenderService();
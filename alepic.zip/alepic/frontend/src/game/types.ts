export interface Position {
  x: number;
  y: number;
}

export interface AlepeJumpEvent {
  previousPosition: Position;
  newPosition: Position;
  blockHeight: bigint;
  timestamp: number;
  landedChunkId: number;
  rewardIssued: boolean;
  rewardAmount?: bigint; // Если награда была выдана
  winnerAddress?: string; // Адрес победителя (если есть)
}

export interface GameConfig {
  jumpIntervalBlocks: number; // 100,000 блоков
  canvasWidth: number;        // 4096
  canvasHeight: number;       // 2160
  chunkSize: number;          // 16
  rewardPercent: number;      // 1% от казны
}
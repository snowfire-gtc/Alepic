import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { storageService } from '../services/storageService';
import { networkManager } from '../config/network';
import { Button } from '../components/ui/Button';
import { DEFAULT_BILLBOARD_PROFILES } from '../config/billboardConfig';
import { PinPadModal } from '../components/ui/PinPadModal';
import { logger } from '../utils/logger';

export default function SettingsScreen() {
  const router = useRouter();
  const [settings, setSettings] = useState<any>(null);
  const [showBillboardPin, setShowBillboardPin] = useState(false);
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const saved = await storageService.getSettings();
      setSettings(saved);
    } catch (e) {
      logger.error('Settings', 'Load failed', e);
    } finally {
      setLoading(false);
    }
  };

  const toggleSetting = async (key: string, value: any) => {
    if (!settings) return;
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    await storageService.saveSettings(newSettings);
    
    if (key === 'network') {
      networkManager.setNetwork(value);
      Alert.alert('Network Changed', `Switched to ${value}. Restart recommended.`);
    }
  };

  const requestBillboardActivation = (profileId: string) => {
    setSelectedProfileId(profileId);
    setShowBillboardPin(true);
  };

  const handlePinSuccess = async () => {
    if (!selectedProfileId) return;
    
    try {
      await storageService.setBillboardMode(true, selectedProfileId);
      setShowBillboardPin(false);
      // Перенаправление на экран биллборда
      router.replace('/billboard');
    } catch (e) {
      Alert.alert('Error', 'Failed to activate billboard mode');
    }
  };

  const handleClearCache = async () => {
    Alert.alert('Clear Cache?', 'This will force re-download of all chunk data.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clear',
        style: 'destructive',
        onPress: async () => {
          await storageService.clearCache();
          Alert.alert('Success', 'Cache cleared.');
        },
      },
    ]);
  };

  if (loading || !settings) {
    return <View style={styles.centerContainer}><Text style={styles.text}>Loading...</Text></View>;
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      
      {/* Section: Billboard Mode (NEW) */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Billboard Mode (Sec 8.1)</Text>
        <Text style={styles.sectionDesc}>Activate kiosk mode for public displays. Requires Admin PIN.</Text>
        
        {DEFAULT_BILLBOARD_PROFILES.map((profile) => (
          <TouchableOpacity
            key={profile.id}
            style={styles.profileRow}
            onPress={() => requestBillboardActivation(profile.id)}
          >
            <View style={styles.rowText}>
              <Text style={styles.label}>{profile.name}</Text>
              <Text style={styles.subLabel}>
                {profile.fitToScreen ? 'Auto-Fit' : `Zoom: ${profile.zoomLevel}x`} • Refresh: {profile.refreshInterval/1000}s
              </Text>
            </View>
            <Ionicons name="play-circle-outline" size={28} color="#00FF00" />
          </TouchableOpacity>
        ))}
      </View>

      {/* Section: Network */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Network</Text>
        <View style={styles.optionGroup}>
          {(['devnet', 'testnet', 'mainnet'] as any[]).map((net) => (
            <TouchableOpacity
              key={net}
              style={[styles.netBtn, settings.network === net && styles.netBtnActive]}
              onPress={() => toggleSetting('network', net)}
            >
              <Text style={[styles.netText, settings.network === net && styles.netTextActive]}>
                {net}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Section: Data */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Data Management</Text>
        <Button title="Clear Image Cache" onPress={handleClearCache} variant="danger" />
      </View>

      <View style={styles.footer}>
        <Text style={styles.version}>Alepic Client v7.0</Text>
      </View>

      {/* PIN Modal */}
      <PinPadModal
        visible={showBillboardPin}
        onClose={() => { setShowBillboardPin(false); setSelectedProfileId(null); }}
        onSuccess={handlePinSuccess}
        title="Enter Admin PIN"
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  content: { padding: 20 },
  centerContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  text: { color: '#FFF' },
  section: { marginBottom: 30 },
  sectionTitle: { color: '#FFF', fontSize: 18, fontWeight: 'bold', marginBottom: 8 },
  sectionDesc: { color: '#888', fontSize: 13, marginBottom: 15 },
  profileRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1A1A1A',
    padding: 16,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  rowText: { flex: 1 },
  label: { color: '#EEE', fontSize: 15, fontWeight: '600' },
  subLabel: { color: '#666', fontSize: 12, marginTop: 4 },
  optionGroup: { flexDirection: 'row', gap: 10 },
  netBtn: { flex: 1, padding: 10, borderRadius: 8, backgroundColor: '#222', alignItems: 'center', borderWidth: 1, borderColor: '#333' },
  netBtnActive: { backgroundColor: '#003300', borderColor: '#00FF00' },
  netText: { color: '#AAA' },
  netTextActive: { color: '#00FF00', fontWeight: 'bold' },
  footer: { marginTop: 20, alignItems: 'center', paddingBottom: 40 },
  version: { color: '#444', fontSize: 12 },
});
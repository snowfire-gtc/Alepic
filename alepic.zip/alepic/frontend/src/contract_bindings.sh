npx @alephium/cli compile -n testnet
# Артефакты появятся в ./artifacts/ts/
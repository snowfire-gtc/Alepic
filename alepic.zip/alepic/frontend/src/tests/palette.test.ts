import { PALETTE, getColorByIndex, getRgbByIndex, getClosestPaletteIndex, getPaletteUint8Array } from '../data/palette';

describe('Color Palette (Whitepaper Sec 3.1)', () => {
  
  it('should have exactly 16 colors (4-bit)', () => {
    expect(PALETTE.length).toBe(16);
  });

  describe('getColorByIndex', () => {
    it('should return correct hex for valid indices', () => {
      expect(getColorByIndex(0)).toBe('#000000'); // Black
      expect(getColorByIndex(3)).toBe('#00FF00'); // Alephium Green
      expect(getColorByIndex(15)).toBe('#000080'); // Navy
    });

    it('should fallback to black for invalid indices', () => {
      expect(getColorByIndex(-1)).toBe('#000000');
      expect(getColorByIndex(16)).toBe('#000000');
      expect(getColorByIndex(100)).toBe('#000000');
    });
  });

  describe('getRgbByIndex', () => {
    it('should return correct RGB object', () => {
      const white = getRgbByIndex(1);
      expect(white).toEqual({ r: 255, g: 255, b: 255 });
      
      const red = getRgbByIndex(2);
      expect(red).toEqual({ r: 255, g: 0, b: 0 });
    });
  });

  describe('getClosestPaletteIndex', () => {
    it('should find exact match', () => {
      expect(getClosestPaletteIndex('#00FF00')).toBe(3);
      expect(getClosestPaletteIndex('#FFFFFF')).toBe(1);
    });

    it('should find nearest neighbor for similar colors', () => {
      // Светло-зеленый должен мапиться на зеленый (3), а не на черный
      expect(getClosestPaletteIndex('#10FF10')).toBe(3);
      
      // Темно-серый должен мапиться на серый (9) или черный (0) в зависимости от дистанции
      // #404040 ближе к #808080 (Gray) чем к #000000? 
      // Dist to Black: 64*64*3 = 12288
      // Dist to Gray: (128-64)^2 * 3 = 64*64*3 = 12288 (одинаково, берем первый встреченный или минимальный индекс)
      // В нашей реализации цикл идет от 0, так что если дистанция равна, останется предыдущий минимум.
      // Проверим явный случай: #707070 явно ближе к Gray (#808080)
      expect(getClosestPaletteIndex('#707070')).toBe(9); 
    });
  });

  describe('getPaletteUint8Array', () => {
    it('should generate buffer of size 48 (16 colors * 3 channels)', () => {
      const buffer = getPaletteUint8Array();
      expect(buffer.length).toBe(48);
      expect(buffer instanceof Uint8Array).toBe(true);
    });

    it('should contain correct RGB values in order', () => {
      const buffer = getPaletteUint8Array();
      // Index 0 (Black): R=0, G=0, B=0
      expect(buffer[0]).toBe(0);
      expect(buffer[1]).toBe(0);
      expect(buffer[2]).toBe(0);
      
      // Index 1 (White): R=255, G=255, B=255 (positions 3, 4, 5)
      expect(buffer[3]).toBe(255);
      expect(buffer[4]).toBe(255);
      expect(buffer[5]).toBe(255);
    });
  });
});
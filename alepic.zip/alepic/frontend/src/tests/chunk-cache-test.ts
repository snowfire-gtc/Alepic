import { chunkCache } from '../chunkCache';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { storageService } from '../../services/storageService';
import { ChunkInfo } from '../../contracts/types';

jest.mock('@react-native-async-storage/async-storage');
jest.mock('../../services/storageService');

describe('ChunkCache Manager', () => {
  const testChunkId = 500;
  const testChunkData: ChunkInfo = {
    ownerId: '0xTestOwner',
    colorIndex: 7,
    lastUpdatedBlock: 12345n,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers(); // Важно для тестирования debounce
    
    // Сброс внутреннего состояния singleton
    (chunkCache as any).memoryStore.clear();
    (chunkCache as any).pendingUpdates.clear();
    (chunkCache as any).isInitialized = false;
    if ((chunkCache as any).saveTimeout) clearTimeout((chunkCache as any).saveTimeout);
    
    (storageService.getChunks as jest.Mock).mockResolvedValue({});
    (AsyncStorage.getItem as jest.Mock).mockResolvedValue(null);
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('Initialization', () => {
    it('should load metadata and chunks from storage on init', async () => {
      const storedChunks = { [testChunkId]: testChunkData };
      const metaJson = JSON.stringify({
        lastSyncedBlockHeight: '1000',
        totalCachedChunks: 1,
        lastUpdatedTimestamp: Date.now(),
      });

      (storageService.getChunks as jest.Mock).mockResolvedValue(storedChunks);
      (AsyncStorage.getItem as jest.Mock).mockResolvedValue(metaJson);

      await chunkCache.initialize();

      expect(chunkCache.get(testChunkId)).toEqual(testChunkData);
      expect(chunkCache.getSyncHeight()).toBe(1000n);
      expect((chunkCache as any).isInitialized).toBe(true);
    });

    it('should handle corrupted metadata gracefully', async () => {
      (AsyncStorage.getItem as jest.Mock).mockResolvedValue('invalid-json');
      (storageService.getChunks as jest.Mock).mockResolvedValue({});

      await expect(chunkCache.initialize()).resolves.not.toThrow();
      expect(chunkCache.getSyncHeight()).toBe(0n); // Default value
    });
  });

  describe('Write Operations & Debouncing', () => {
    beforeEach(async () => {
      await chunkCache.initialize();
    });

    it('should write to memory immediately but delay disk write', () => {
      chunkCache.set(testChunkId, testChunkData);

      expect(chunkCache.get(testChunkId)).toEqual(testChunkData);
      expect(storageService.saveChunks).not.toHaveBeenCalled();
      expect((chunkCache as any).pendingUpdates.has(testChunkId)).toBe(true);
    });

    it('should flush to disk after debounce delay', async () => {
      chunkCache.set(testChunkId, testChunkData);

      // Проматываем время вперед (delay = 1000ms в реализации)
      jest.advanceTimersByTime(1100);
      
      // Ждем выполнения асинхронных операций
      await Promise.resolve(); 

      expect(storageService.saveChunks).toHaveBeenCalledWith({ [testChunkId]: testChunkData });
      expect((chunkCache as any).pendingUpdates.size).toBe(0);
    });

    it('should batch multiple updates into single disk write', async () => {
      const chunk2 = { ...testChunkData, colorIndex: 8 };
      
      chunkCache.set(100, testChunkData);
      chunkCache.set(101, chunk2);
      chunkCache.set(102, { ...testChunkData, colorIndex: 9 });

      jest.advanceTimersByTime(1100);
      await Promise.resolve();

      expect(storageService.saveChunks).toHaveBeenCalledTimes(1);
      const savedData = (storageService.saveChunks as jest.Mock).mock.calls[0][0];
      expect(Object.keys(savedData).length).toBe(3);
      expect(savedData[100]).toBeDefined();
      expect(savedData[101]).toBeDefined();
      expect(savedData[102]).toBeDefined();
    });

    it('should reset timer on new writes before flush', async () => {
      chunkCache.set(1, testChunkData);
      jest.advanceTimersByTime(500); // Половина времени ожидания
      
      chunkCache.set(2, testChunkData); // Новый запись сбрасывает таймер
      jest.advanceTimersByTime(600); // Еще 600мс (итого 1100 от первой, но только 600 от второй)
      
      // Не должно сработать, так как таймер сбросился на второй записи
      expect(storageService.saveChunks).not.toHaveBeenCalled();

      jest.advanceTimersByTime(500); // Добиваем до 1100 от второй записи
      await Promise.resolve();

      expect(storageService.saveChunks).toHaveBeenCalledTimes(1);
    });
  });

  describe('Sync Height Management', () => {
    beforeEach(async () => {
      await chunkCache.initialize();
    });

    it('should update sync height immediately (no debounce)', async () => {
      const newHeight = 50000n;
      
      chunkCache.updateSyncHeight(newHeight);

      expect(chunkCache.getSyncHeight()).toBe(newHeight);
      // Метаданные должны сохраниться сразу
      expect(AsyncStorage.setItem).toHaveBeenCalledWith(
        expect.any(String),
        expect.stringContaining('50000')
      );
    });
  });

  describe('Clear & Reset', () => {
    beforeEach(async () => {
      await chunkCache.initialize();
      chunkCache.set(testChunkId, testChunkData);
    });

    it('should clear memory and pending writes', async () => {
      await chunkCache.clear();

      expect(chunkCache.get(testChunkId)).toBeUndefined();
      expect((chunkCache as any).pendingUpdates.size).toBe(0);
      expect(storageService.clearCache).toHaveBeenCalled();
      expect(AsyncStorage.removeItem).toHaveBeenCalledWith(expect.stringContaining('metadata'));
    });

    it('should cancel pending flush on clear', async () => {
      chunkCache.set(999, testChunkData);
      // Таймер еще не сработал
      
      await chunkCache.clear();
      jest.advanceTimersByTime(2000);
      await Promise.resolve();

      // Данные не должны быть сохранены, так как кэш очищен
      // (Зависит от реализации, но в идеале pendingUpdates очищается)
      expect(storageService.saveChunks).not.toHaveBeenCalledWith(expect.objectContaining({ '999': expect.anything() }));
    });
  });
});
import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  TouchableOpacity,
  Dimensions,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

export type ToastType = 'success' | 'error' | 'info' | 'warning';

interface ToastProps {
  message: string;
  type?: ToastType;
  visible: boolean;
  onHide: () => void;
  duration?: number; // Время отображения в мс (по умолчанию 3000)
  actionLabel?: string; // Текст кнопки действия (опционально)
  onActionPress?: () => void; // Обработчик кнопки действия
}

export const Toast: React.FC<ToastProps> = ({
  message,
  type = 'info',
  visible,
  onHide,
  duration = 3000,
  actionLabel,
  onActionPress,
}) => {
  const fadeAnim = React.useRef(new Animated.Value(0)).current;
  const slideAnim = React.useRef(new Animated.Value(100)).current; // Начальная позиция снизу

  // Конфигурация стилей в зависимости от типа
  const getConfig = () => {
    switch (type) {
      case 'success':
        return {
          bgColor: '#003300',
          borderColor: '#00FF00',
          icon: 'checkmark-circle',
          iconColor: '#00FF00',
        };
      case 'error':
        return {
          bgColor: '#330000',
          borderColor: '#FF4444',
          icon: 'close-circle',
          iconColor: '#FF4444',
        };
      case 'warning':
        return {
          bgColor: '#332200',
          borderColor: '#FFAA00',
          icon: 'warning',
          iconColor: '#FFAA00',
        };
      case 'info':
      default:
        return {
          bgColor: '#001133',
          borderColor: '#0088FF',
          icon: 'information-circle',
          iconColor: '#0088FF',
        };
    }
  };

  const config = getConfig();

  useEffect(() => {
    if (visible) {
      // Анимация появления
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.spring(slideAnim, {
          toValue: 0,
          tension: 50,
          friction: 7,
          useNativeDriver: true,
        }),
      ]).start();

      // Автоскрытие через заданное время
      const timer = setTimeout(() => {
        hideToast();
      }, duration);

      return () => clearTimeout(timer);
    } else {
      // Сброс анимации если visible стал false извне
      fadeAnim.setValue(0);
      slideAnim.setValue(100);
    }
  }, [visible]);

  const hideToast = () => {
    // Анимация исчезновения
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 100,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onHide();
    });
  };

  if (!visible && fadeAnim._value === 0) return null;

  return (
    <Animated.View
      style={[
        styles.container,
        {
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }],
          backgroundColor: config.bgColor,
          borderColor: config.borderColor,
        },
      ]}
    >
      <View style={styles.content}>
        <Ionicons name={config.icon as any} size={24} color={config.iconColor} style={styles.icon} />
        
        <Text style={styles.message} numberOfLines={2}>
          {message}
        </Text>

        {actionLabel && onActionPress && (
          <TouchableOpacity onPress={onActionPress} style={styles.actionButton}>
            <Text style={[styles.actionText, { color: config.iconColor }]}>
              {actionLabel}
            </Text>
          </TouchableOpacity>
        )}

        {!actionLabel && (
          <TouchableOpacity onPress={hideToast} style={styles.closeButton}>
            <Ionicons name="close" size={20} color="#888" />
          </TouchableOpacity>
        )}
      </View>
      
      {/* Индикатор прогресса времени (опционально) */}
      {duration > 0 && (
        <View style={styles.progressBarBackground}>
          <Animated.View 
            style={[
              styles.progressBarFill, 
              { 
                backgroundColor: config.iconColor,
                // Простая эмуляция прогресса через ширину требует отдельной анимации, 
                // здесь оставим статическим для простоты или можно добавить логику
              } 
            ]} 
          />
        </View>
      )}
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 30, // Отступ снизу
    left: 20,
    right: 20,
    borderRadius: 12,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 8, // Для Android
    zIndex: 9999,
    overflow: 'hidden',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    paddingRight: 12,
  },
  icon: {
    marginRight: 12,
  },
  message: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '500',
    lineHeight: 20,
  },
  actionButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginLeft: 8,
  },
  actionText: {
    fontWeight: 'bold',
    fontSize: 14,
    textTransform: 'uppercase',
  },
  closeButton: {
    padding: 4,
    marginLeft: 8,
  },
  progressBarBackground: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  progressBarFill: {
    height: '100%',
    width: '100%', // В полной реализации здесь должна быть анимированная ширина
  },
});
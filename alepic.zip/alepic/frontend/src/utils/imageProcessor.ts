import { PaletteEntry, getRgbByIndex } from '../data/palette';

/**
 * Конвертирует 128 байт (сжатое состояние чанка 16x16, 4-bit цвет)
 * в Uint8Array RGBA для рендеринга через React Native Skia.
 */
export const decompressChunkToRGBA = (pixelData: Uint8Array): Uint8Array => {
  if (!pixelData || pixelData.length !== 128) {
    // Возвращаем прозрачный или черный чанк при ошибке
    return new Uint8Array(16 * 16 * 4).fill(0); 
  }

  const rgbaBuffer = new Uint8Array(16 * 16 * 4); // 256 pixels * 4 channels (RGBA)
  let rgbaIndex = 0;

  for (let i = 0; i < 128; i++) {
    const byte = pixelData[i];
    
    // Извлекаем два 4-битных индекса из одного байта
    const colorIndex1 = (byte >> 4) & 0x0F; // Старший ниббл (левый пиксель)
    const colorIndex2 = byte & 0x0F;        // Младший ниббл (правый пиксель)

    // Пиксель 1
    const rgb1 = getRgbByIndex(colorIndex1);
    rgbaBuffer[rgbaIndex++] = rgb1.r;
    rgbaBuffer[rgbaIndex++] = rgb1.g;
    rgbaBuffer[rgbaIndex++] = rgb1.b;
    rgbaBuffer[rgbaIndex++] = 255; // Alpha

    // Пиксель 2
    const rgb2 = getRgbByIndex(colorIndex2);
    rgbaBuffer[rgbaIndex++] = rgb2.r;
    rgbaBuffer[rgbaIndex++] = rgb2.g;
    rgbaBuffer[rgbaIndex++] = rgb2.b;
    rgbaBuffer[rgbaIndex++] = 255; // Alpha
  }

  return rgbaBuffer;
};

/**
 * Создает объект Image для Skia из сырых данных чанка.
 * Примечание: В реальном проекте используйте makeImageFromEncoded или аналогичный API Skia.
 * Здесь представлена логика подготовки буфера.
 */
export const createSkiaImageSource = (pixelData: Uint8Array) => {
  const rgbaData = decompressChunkToRGBA(pixelData);
  // Возвращаем объект, совместимый с пропом 'image' компонента Skia
  // В зависимости от версии react-native-skia API может отличаться:
  // return Skia.Image.makeFromEncoded(rgbaData, 16, 16); 
  return { data: rgbaData, width: 16, height: 16 };
};
import { networkManager } from './config/network';
import { storageService } from './services/storageService';
import { chunkCache } from './data/chunkCache';
import { nodeService } from './services/nodeService';
import { contractService } from './contracts/AlepicContract';
import { AlepeEngine } from './game/AlepeEngine';
import { RewardChecker } from './game/rewardChecker';
import { notificationService } from './services/notificationService';
import { logger } from './utils/logger';
import { AlepeState } from './contracts/types';

export class AppController {
  private pollInterval: NodeJS.Timeout | null = null;
  private isRunning: boolean = false;
  private lastKnownAlepeState: AlepeState | null = null;

  async start() {
    if (this.isRunning) return;

    logger.info('AppController', 'Starting Alepic System v7.0...');
    this.isRunning = true;

    try {
      await storageService.getSettings();
      await chunkCache.initialize();

      const settings = await storageService.getSettings();
      networkManager.setNetwork(settings.network);

      this.startPolling();
      await notificationService.initialize();

      logger.info('AppController', 'System started successfully');
    } catch (error) {
      logger.error('AppController', 'Failed to start', error);
      this.isRunning = false;
      throw error;
    }
  }

  stop() {
    if (!this.isRunning) return;
    logger.info('AppController', 'Stopping system...');
    this.isRunning = false;

    if (this.pollInterval) clearInterval(this.pollInterval);
    this.pollInterval = null;
  }

  private startPolling() {
    const POLL_INTERVAL_MS = 5000;
    this.pollInterval = setInterval(async () => {
      if (!this.isRunning) return;
      try {
        const currentBlockHeight = await nodeService.getCurrentBlockHeight();
        const lastSyncHeight = chunkCache.getSyncHeight();
        
        if (currentBlockHeight > lastSyncHeight) {
          // Logic for incremental sync of history blocks
          // ... (load events and update chunkCache)
          chunkCache.updateSyncHeight(currentBlockHeight);
        }

        await this.checkAlepeState(currentBlockHeight);
      } catch (error) {
        logger.error('AppController', 'Polling error', error);
      }
    }, POLL_INTERVAL_MS);
  }

  private async checkAlepeState(currentBlockHeight: bigint) {
    try {
      const alepeState = await contractService.getAlepeState();
      
      if (this.lastKnownAlepeState && alepeState.nextJumpBlock !== this.lastKnownAlepeState.nextJumpBlock) {
        logger.info('AppController', 'Alepe has jumped! Checking rewards...');
        
        const prediction = AlepeEngine.predictNextMove(this.lastKnownAlepeState, currentBlockHeight);
        const chunkInfo = await contractService.getChunkInfo(prediction.currentChunkId);
        
        const winEvent = RewardChecker.processJumpResult(
          chunkInfo,
          alepeState.treasuryBalance,
          { x: alepeState.x, y: alepeState.y },
          { x: this.lastKnownAlepeState.x, y: this.lastKnownAlepeState.y },
          currentBlockHeight
        );

        if (winEvent.rewardIssued && winEvent.winnerAddress) {
          logger.info('AppController', `Reward issued to ${winEvent.winnerAddress}`);
          
          const currentUserAddress = await this.getCurrentUserAddress(); 
          if (currentUserAddress && winEvent.winnerAddress === currentUserAddress) {
            notificationService.notifyAlepeJump(
              winEvent.landedChunkId, 
              true, 
              winEvent.rewardAmount
            );
          }
        }
      }

      this.lastKnownAlepeState = alepeState;

    } catch (error) {
      logger.error('AppController', 'Error checking Alepe state', error);
    }
  }

  private async getCurrentUserAddress(): Promise<string | null> {
    try {
      const account = await (global as any).alephium?.wallet?.getSelectedAccount();
      return account ? account.address : null;
    } catch {
      return null;
    }
  }
}

export const appController = new AppController();
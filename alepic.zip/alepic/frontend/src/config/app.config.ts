import { ExpoConfig, ConfigContext } from 'expo/config';

// Определение типов для переменных окружения
interface CustomEnv {
  EXPO_PUBLIC_APP_VERSION?: string;
  EXPO_PUBLIC_API_NODE_URL?: string;
  EXPO_PUBLIC_CONTRACT_ADDRESS?: string;
  EXPO_PUBLIC_SENTRY_DSN?: string;
  EXPO_PUBLIC_ENABLE_DEV_MODE?: string;
}

export default ({ config }: ConfigContext): ExpoConfig => {
  const env = process.env as unknown as CustomEnv;
  
  // Версия приложения соответствует версии Whitepaper (7.0)
  const appVersion = env.EXPO_PUBLIC_APP_VERSION || '7.0.0';
  const buildNumber = '1'; // Инкрементальный номер сборки

  return {
    expo: {
      name: 'Alepic',
      slug: 'alepic-canvas',
      version: appVersion,
      orientation: 'default',
      icon: './assets/images/icon.png',
      scheme: 'alepic',
      userInterfaceStyle: 'dark', // Принудительная темная тема согласно дизайну
      splash: {
        image: './assets/images/splash.png',
        resizeMode: 'contain',
        backgroundColor: '#000000',
      },
      assetBundlePatterns: [
        '**/*'
      ],
      
      // --- Настройки платформы iOS ---
      ios: {
        supportsTablet: true,
        bundleIdentifier: 'org.alephium.alepic',
        buildNumber: buildNumber,
        infoPlist: {
          NSCameraUsageDescription: 'Alepic needs camera access to scan QR codes for Billboard Mode activation.',
          NSFaceIDUsageDescription: 'Alepic uses FaceID to secure wallet transactions.',
          UIBackgroundModes: ['fetch', 'remote-notification'], // Для фоновой синхронизации Alepe
        },
        associatedDomains: [
          'applinks:alepic.io',
          'webcredentials:alepic.io'
        ],
      },

      // --- Настройки платформы Android ---
      android: {
        adaptiveIcon: {
          foregroundImage: './assets/images/adaptive-icon.png',
          backgroundColor: '#000000',
        },
        package: 'org.alephium.alepic',
        versionCode: parseInt(buildNumber),
        permissions: [
          'CAMERA',
          'VIBRATE',
          'INTERNET',
          'ACCESS_NETWORK_STATE',
          'USE_BIOMETRIC',
          'USE_FINGERPRINT',
          'POST_NOTIFICATIONS' // Требуется для уведомлений о прыжках Alepe
        ],
      },

      // --- Настройки Web (PWA) ---
      web: {
        bundler: 'metro',
        output: 'static',
        favicon: './assets/images/favicon.png',
        description: 'Alephium Collaborative Canvas - A decentralized 4K public art experiment.',
        meta: {
          'theme-color': '#000000',
          'apple-mobile-web-app-capable': 'yes',
          'apple-mobile-web-app-status-bar-style': 'black-translucent',
          'viewport': 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no', // Важно для Canvas зума
        },
        configureWebpack: (config) => {
          // Оптимизация для работы с большими буферами (Skia/WebGL)
          config.resolve = {
            ...config.resolve,
            fallback: {
              crypto: require.resolve('crypto-browserify'),
              stream: require.resolve('stream-browserify'),
              buffer: require.resolve('buffer'),
            },
          };
          return config;
        },
      },

      // --- Плагины ---
      plugins: [
        'expo-router',
        [
          'expo-notifications',
          {
            icon: './assets/images/notification-icon.png',
            color: '#00FF00',
            sounds: ['./assets/sounds/alepe-jump.wav'],
          },
        ],
        [
          'expo-camera',
          {
            cameraPermission: 'Allow Alepic to access your camera for QR code scanning and Billboard linking.',
          },
        ],
        [
          'expo-build-properties',
          {
            ios: {
              useFrameworks: 'static',
            },
            android: {
              enableProguardInReleaseBuilds: true,
              extraProguardRules: '-keep class com.swmansion.skia.** { *; }', // Сохранение классов Skia
            },
          },
        ],
        // Плагин для полифилов криптографии (необходим для alephium-web3)
        'react-native-quick-crypto',
      ],

      // --- Схема обновлений (EAS Update) ---
      updates: {
        url: 'https://u.expo.dev/your-project-id',
        enabled: true,
        checkAutomatically: 'ON_LOAD',
        fallbackToCacheTimeout: 0,
      },

      // --- Дополнительные настройки ---
      extra: {
        router: {
          origin: false,
        },
        eas: {
          projectId: 'your-eas-project-id',
        },
        // Передача переменных окружения в приложение
        apiUrl: env.EXPO_PUBLIC_API_NODE_URL || 'https://node.testnet.alephium.org',
        contractAddress: env.EXPO_PUBLIC_CONTRACT_ADDRESS || '',
        sentryDsn: env.EXPO_PUBLIC_SENTRY_DSN,
        isDevMode: env.EXPO_PUBLIC_ENABLE_DEV_MODE === 'true',
        whitepaperVersion: '7.0',
      },
      
      owner: 'alephium-community',
      runtimeVersion: {
        policy: 'appVersion',
      },
    },
  };
};
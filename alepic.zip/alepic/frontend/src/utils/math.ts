const CANVAS_WIDTH = 4096;
const CANVAS_HEIGHT = 2160;
const CHUNK_SIZE = 16;
const GRID_WIDTH = CANVAS_WIDTH / CHUNK_SIZE; // 256
const GRID_HEIGHT = CANVAS_HEIGHT / CHUNK_SIZE; // 135

/**
 * Преобразовать глобальные координаты пикселя в ID чанка
 */
export const pixelToChunkId = (x: number, y: number): number => {
  const chunkX = Math.floor(x / CHUNK_SIZE);
  const chunkY = Math.floor(y / CHUNK_SIZE);
  
  // Проверка границ
  if (chunkX < 0 || chunkX >= GRID_WIDTH || chunkY < 0 || chunkY >= GRID_HEIGHT) {
    return -1;
  }
  
  return chunkY * GRID_WIDTH + chunkX;
};

/**
 * Преобразовать ID чанка в координаты верхнего левого угла (в пикселях)
 */
export const chunkIdToPixel = (chunkId: number): { x: number, y: number } => {
  const chunkX = chunkId % GRID_WIDTH;
  const chunkY = Math.floor(chunkId / GRID_WIDTH);
  return {
    x: chunkX * CHUNK_SIZE,
    y: chunkY * CHUNK_SIZE
  };
};

/**
 * Реализация Wrap-Around логики для Alepe (как в контракте)
 */
export const wrapCoordinate = (val: number, max: number): number => {
  return ((val % max) + max) % max;
};
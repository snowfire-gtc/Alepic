import { NodeProvider } from 'alephium-web3';

export type NetworkType = 'mainnet' | 'testnet' | 'devnet';

export interface NetworkConfig {
  id: NetworkType;
  nodeUrl: string;
  explorerUrl: string;
  chainId: number;
  contractAddress?: string; // Адрес деплоя контракта Alepic
}

export const NETWORKS: Record<NetworkType, NetworkConfig> = {
  devnet: {
    id: 'devnet',
    nodeUrl: 'http://127.0.0.1:22973',
    explorerUrl: 'http://127.0.0.1:3000',
    chainId: 4,
    contractAddress: undefined, // Будет установлен после локального деплоя
  },
  testnet: {
    id: 'testnet',
    nodeUrl: 'https://node.testnet.alephium.org',
    explorerUrl: 'https://explorer.testnet.alephium.org',
    chainId: 3,
    contractAddress: 'YOUR_TESTNET_CONTRACT_ADDRESS_HERE', // Заполнить в Phase 2
  },
  mainnet: {
    id: 'mainnet',
    nodeUrl: 'https://node.mainnet.alephium.org',
    explorerUrl: 'https://explorer.alephium.org',
    chainId: 1,
    contractAddress: 'YOUR_MAINNET_CONTRACT_ADDRESS_HERE', // Заполнить в Phase 4
  },
};

export class NetworkManager {
  private currentNetwork: NetworkType = 'testnet'; // По умолчанию testnet для разработки
  private provider: NodeProvider | null = null;

  setNetwork(networkId: NetworkType) {
    this.currentNetwork = networkId;
    const config = NETWORKS[networkId];
    this.provider = new NodeProvider(config.nodeUrl);
    console.log(`Switched to ${networkId}: ${config.nodeUrl}`);
  }

  getProvider(): NodeProvider {
    if (!this.provider) {
      this.setNetwork(this.currentNetwork);
    }
    return this.provider!;
  }

  getConfig(): NetworkConfig {
    return NETWORKS[this.currentNetwork];
  }

  getContractAddress(): string {
    const addr = NETWORKS[this.currentNetwork].contractAddress;
    if (!addr) throw new Error(`Contract address not configured for ${this.currentNetwork}`);
    return addr;
  }
}

export const networkManager = new NetworkManager();